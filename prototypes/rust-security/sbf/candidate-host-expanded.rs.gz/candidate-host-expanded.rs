#![feature(prelude_import)]
extern crate std;
#[prelude_import]
use std::prelude::rust_2021::*;
use anchor_lang::prelude::*;

#[doc = r" The static program ID"]
pub static ID: anchor_lang::solana_program::pubkey::Pubkey =
    anchor_lang::solana_program::pubkey::Pubkey::from_str_const("Fg6PaFpoGXkYsidMpWxTWqkZq26fPRmKZX54C9V8uB9m");
#[doc = r" Const version of `ID`"]
pub const ID_CONST: anchor_lang::solana_program::pubkey::Pubkey =
    anchor_lang::solana_program::pubkey::Pubkey::from_str_const("Fg6PaFpoGXkYsidMpWxTWqkZq26fPRmKZX54C9V8uB9m");
#[doc = r" Confirms that a given pubkey is equivalent to the program ID"]
pub fn check_id(id: &anchor_lang::solana_program::pubkey::Pubkey) -> bool {
    id == &ID
}
#[doc = r" Returns the program ID"]
pub fn id() -> anchor_lang::solana_program::pubkey::Pubkey { ID }
#[doc = r" Const version of `ID`"]
pub const fn id_const() -> anchor_lang::solana_program::pubkey::Pubkey {
    ID_CONST
}

const COMMISSION_BPS: u64 = 500;
const BPS: u64 = 10_000;
const FULL_PAY_THRESHOLD_BPS: u64 = 9_000;
const DISPUTE_WINDOW_SECONDS: i64 = 3_600;
const MAX_BOOKING_SECONDS: u32 = 86_400;
const MAX_EXPIRY_SECONDS: i64 = 7 * 86_400;

use self::gpu_escrow::*;











// Read the value before taking a mutable borrow of the escrow account.
// Keeping both borrows in a single call expression is rejected by the
// Rust borrow checker and prevented the on-chain program from compiling.




















/// # Safety
#[no_mangle]
pub unsafe extern "C" fn entrypoint(input: *mut u8) -> u64 {
    let (program_id, accounts, instruction_data) =
        unsafe { ::solana_program_entrypoint::deserialize(input) };
    match entry(program_id, &accounts, instruction_data) {
        Ok(()) => ::solana_program_entrypoint::SUCCESS,
        Err(error) => error.into(),
    }
}
#[doc =
r" The Anchor codegen exposes a programming model where a user defines"]
#[doc = r" a set of methods inside of a `#[program]` module in a way similar"]
#[doc =
r" to writing RPC request handlers. The macro then generates a bunch of"]
#[doc =
r" code wrapping these user defined methods into something that can be"]
#[doc = r" executed on Solana."]
#[doc = r""]
#[doc = r" These methods fall into one category for now."]
#[doc = r""]
#[doc = r" Global methods - regular methods inside of the `#[program]`."]
#[doc = r""]
#[doc = r" Care must be taken by the codegen to prevent collisions between"]
#[doc =
r" methods in these different namespaces. For this reason, Anchor uses"]
#[doc = r" a variant of sighash to perform method dispatch, rather than"]
#[doc = r" something like a simple enum variant discriminator."]
#[doc = r""]
#[doc = r" The execution flow of the generated code can be roughly outlined:"]
#[doc = r""]
#[doc = r" * Start program via the entrypoint."]
#[doc = r" * Check whether the declared program id matches the input program"]
#[doc = r"   id. If it's not, return an error."]
#[doc =
r" * Find and invoke the method based on whether the instruction data"]
#[doc = r"   starts with the method's discriminator."]
#[doc = r" * Run the method handler wrapper. This wraps the code the user"]
#[doc = r"   actually wrote, deserializing the accounts, constructing the"]
#[doc = r"   context, invoking the user's code, and finally running the exit"]
#[doc = r"   routine, which typically persists account changes."]
#[doc = r""]
#[doc = r" The `entry` function here, defines the standard entry to a Solana"]
#[doc = r" program, where execution begins."]
pub fn entry<'info>(program_id: &'info Pubkey,
    accounts: &'info [AccountInfo<'info>], data: &'info [u8])
    -> anchor_lang::solana_program::entrypoint::ProgramResult {
    try_entry(program_id, accounts, data).map_err(|e| { e.log(); e.into() })
}
fn try_entry<'info>(program_id: &'info Pubkey,
    accounts: &'info [AccountInfo<'info>], data: &'info [u8])
    -> anchor_lang::Result<()> {
    if *program_id != ID {
        return Err(anchor_lang::error::ErrorCode::DeclaredProgramIdMismatch.into());
    }
    dispatch(program_id, accounts, data)
}
#[doc = r" Module representing the program."]
pub mod program {
    use super::*;
    #[doc = r" Type representing the program."]
    pub struct GpuEscrow;
    #[automatically_derived]
    impl ::core::clone::Clone for GpuEscrow {
        #[inline]
        fn clone(&self) -> GpuEscrow { GpuEscrow }
    }
    impl anchor_lang::Id for GpuEscrow {
        fn id() -> Pubkey { ID }
    }
}
#[doc = r" Performs method dispatch."]
#[doc = r""]
#[doc =
r" Each instruction's discriminator is checked until the given instruction data starts with"]
#[doc = r" the current discriminator."]
#[doc = r""]
#[doc =
r" If a match is found, the instruction handler is called using the given instruction data"]
#[doc = r" excluding the prepended discriminator bytes."]
#[doc = r""]
#[doc =
r" If no match is found, the fallback function is executed if it exists, or an error is"]
#[doc = r" returned if it doesn't exist."]
fn dispatch<'info>(program_id: &'info Pubkey,
    accounts: &'info [AccountInfo<'info>], data: &'info [u8])
    -> anchor_lang::Result<()> {
    if data.starts_with(instruction::InitializeConfig::DISCRIMINATOR) {
        return __private::__global::initialize_config(program_id, accounts,
                &data[instruction::InitializeConfig::DISCRIMINATOR.len()..])
    }
    if data.starts_with(instruction::UpdateConfig::DISCRIMINATOR) {
        return __private::__global::update_config(program_id, accounts,
                &data[instruction::UpdateConfig::DISCRIMINATOR.len()..])
    }
    if data.starts_with(instruction::SetPaused::DISCRIMINATOR) {
        return __private::__global::set_paused(program_id, accounts,
                &data[instruction::SetPaused::DISCRIMINATOR.len()..])
    }
    if data.starts_with(instruction::ProposeAdmin::DISCRIMINATOR) {
        return __private::__global::propose_admin(program_id, accounts,
                &data[instruction::ProposeAdmin::DISCRIMINATOR.len()..])
    }
    if data.starts_with(instruction::AcceptAdmin::DISCRIMINATOR) {
        return __private::__global::accept_admin(program_id, accounts,
                &data[instruction::AcceptAdmin::DISCRIMINATOR.len()..])
    }
    if data.starts_with(instruction::Open::DISCRIMINATOR) {
        return __private::__global::open(program_id, accounts,
                &data[instruction::Open::DISCRIMINATOR.len()..])
    }
    if data.starts_with(instruction::ProposeSettlement::DISCRIMINATOR) {
        return __private::__global::propose_settlement(program_id, accounts,
                &data[instruction::ProposeSettlement::DISCRIMINATOR.len()..])
    }
    if data.starts_with(instruction::Dispute::DISCRIMINATOR) {
        return __private::__global::dispute(program_id, accounts,
                &data[instruction::Dispute::DISCRIMINATOR.len()..])
    }
    if data.starts_with(instruction::Finalize::DISCRIMINATOR) {
        return __private::__global::finalize(program_id, accounts,
                &data[instruction::Finalize::DISCRIMINATOR.len()..])
    }
    if data.starts_with(instruction::ResolveDispute::DISCRIMINATOR) {
        return __private::__global::resolve_dispute(program_id, accounts,
                &data[instruction::ResolveDispute::DISCRIMINATOR.len()..])
    }
    if data.starts_with(instruction::RefundExpired::DISCRIMINATOR) {
        return __private::__global::refund_expired(program_id, accounts,
                &data[instruction::RefundExpired::DISCRIMINATOR.len()..])
    }
    if data.starts_with(anchor_lang::event::EVENT_IX_TAG_LE) {
        return Err(anchor_lang::error::ErrorCode::EventInstructionStub.into());
    }
    Err(anchor_lang::error::ErrorCode::InstructionFallbackNotFound.into())
}
#[doc = r" Create a private module to not clutter the program's namespace."]
#[doc = r" Defines an entrypoint for each individual instruction handler"]
#[doc = r" wrapper."]
mod __private {
    use super::*;
    #[doc =
    r" __global mod defines wrapped handlers for global instructions."]
    pub mod __global {
        use super::*;
        #[inline(never)]
        pub fn initialize_config<'info>(__program_id: &'info Pubkey,
            __accounts: &'info [AccountInfo<'info>], __ix_data: &'info [u8])
            -> anchor_lang::Result<()> {
            ::solana_msg::sol_log("Instruction: InitializeConfig");
            const _: () =
                {
                    const EXPECTED_COUNT: usize =
                        InitializeConfig::__ANCHOR_IX_PARAM_COUNT;
                    const HANDLER_PARAM_COUNT: usize = 2usize;
                    if EXPECTED_COUNT > HANDLER_PARAM_COUNT {
                        {
                            ::core::panicking::panic_fmt(format_args!("#[instruction(...)] on Account `InitializeConfig<\'_>` expects MORE args, the ix `initialize_config(...)` has only 2 args."));
                        };
                    }
                };
            const _: fn() =
                ||
                    {
                        let _: fn(&Pubkey) =
                            InitializeConfig::__anchor_validate_ix_arg_type_0;
                    };
            const _: fn() =
                ||
                    {
                        let _: fn(&Pubkey) =
                            InitializeConfig::__anchor_validate_ix_arg_type_1;
                    };
            let ix =
                instruction::InitializeConfig::deserialize(&mut &__ix_data[..]).map_err(|_|
                            anchor_lang::error::ErrorCode::InstructionDidNotDeserialize)?;
            let instruction::InitializeConfig { platform, oracle } = ix;
            let mut __bumps =
                <InitializeConfig as anchor_lang::Bumps>::Bumps::default();
            let mut __reallocs = ::std::collections::BTreeSet::new();
            let mut __remaining_accounts = __accounts;
            let mut __accounts =
                InitializeConfig::try_accounts(__program_id,
                        &mut __remaining_accounts, __ix_data, &mut __bumps,
                        &mut __reallocs)?;
            #[inline(always)]
            unsafe fn __shorten_invariant_lifetime_remaining_accounts<'a,
                'info: 'a>(value: &'a [AccountInfo<'info>])
                -> &'a [AccountInfo<'a>] {
                unsafe { ::core::mem::transmute(value) }
            }
            let result =
                gpu_escrow::initialize_config(anchor_lang::context::Context::new(__program_id,
                            unsafe {
                                InitializeConfig::__shorten_invariant_lifetime(&mut __accounts)
                            },
                            unsafe {
                                __shorten_invariant_lifetime_remaining_accounts(__remaining_accounts)
                            }, __bumps), platform, oracle)?;
            __accounts.exit(__program_id)
        }
        #[inline(never)]
        pub fn update_config<'info>(__program_id: &'info Pubkey,
            __accounts: &'info [AccountInfo<'info>], __ix_data: &'info [u8])
            -> anchor_lang::Result<()> {
            ::solana_msg::sol_log("Instruction: UpdateConfig");
            const _: () =
                {
                    const EXPECTED_COUNT: usize =
                        AdminConfig::__ANCHOR_IX_PARAM_COUNT;
                    const HANDLER_PARAM_COUNT: usize = 2usize;
                    if EXPECTED_COUNT > HANDLER_PARAM_COUNT {
                        {
                            ::core::panicking::panic_fmt(format_args!("#[instruction(...)] on Account `AdminConfig<\'_>` expects MORE args, the ix `update_config(...)` has only 2 args."));
                        };
                    }
                };
            const _: fn() =
                ||
                    {
                        let _: fn(&Pubkey) =
                            AdminConfig::__anchor_validate_ix_arg_type_0;
                    };
            const _: fn() =
                ||
                    {
                        let _: fn(&Pubkey) =
                            AdminConfig::__anchor_validate_ix_arg_type_1;
                    };
            let ix =
                instruction::UpdateConfig::deserialize(&mut &__ix_data[..]).map_err(|_|
                            anchor_lang::error::ErrorCode::InstructionDidNotDeserialize)?;
            let instruction::UpdateConfig { platform, oracle } = ix;
            let mut __bumps =
                <AdminConfig as anchor_lang::Bumps>::Bumps::default();
            let mut __reallocs = ::std::collections::BTreeSet::new();
            let mut __remaining_accounts = __accounts;
            let mut __accounts =
                AdminConfig::try_accounts(__program_id,
                        &mut __remaining_accounts, __ix_data, &mut __bumps,
                        &mut __reallocs)?;
            #[inline(always)]
            unsafe fn __shorten_invariant_lifetime_remaining_accounts<'a,
                'info: 'a>(value: &'a [AccountInfo<'info>])
                -> &'a [AccountInfo<'a>] {
                unsafe { ::core::mem::transmute(value) }
            }
            let result =
                gpu_escrow::update_config(anchor_lang::context::Context::new(__program_id,
                            unsafe {
                                AdminConfig::__shorten_invariant_lifetime(&mut __accounts)
                            },
                            unsafe {
                                __shorten_invariant_lifetime_remaining_accounts(__remaining_accounts)
                            }, __bumps), platform, oracle)?;
            __accounts.exit(__program_id)
        }
        #[inline(never)]
        pub fn set_paused<'info>(__program_id: &'info Pubkey,
            __accounts: &'info [AccountInfo<'info>], __ix_data: &'info [u8])
            -> anchor_lang::Result<()> {
            ::solana_msg::sol_log("Instruction: SetPaused");
            const _: () =
                {
                    const EXPECTED_COUNT: usize =
                        AdminConfig::__ANCHOR_IX_PARAM_COUNT;
                    const HANDLER_PARAM_COUNT: usize = 1usize;
                    if EXPECTED_COUNT > HANDLER_PARAM_COUNT {
                        {
                            ::core::panicking::panic_fmt(format_args!("#[instruction(...)] on Account `AdminConfig<\'_>` expects MORE args, the ix `set_paused(...)` has only 1 args."));
                        };
                    }
                };
            const _: fn() =
                ||
                    {
                        let _: fn(&bool) =
                            AdminConfig::__anchor_validate_ix_arg_type_0;
                    };
            let ix =
                instruction::SetPaused::deserialize(&mut &__ix_data[..]).map_err(|_|
                            anchor_lang::error::ErrorCode::InstructionDidNotDeserialize)?;
            let instruction::SetPaused { paused } = ix;
            let mut __bumps =
                <AdminConfig as anchor_lang::Bumps>::Bumps::default();
            let mut __reallocs = ::std::collections::BTreeSet::new();
            let mut __remaining_accounts = __accounts;
            let mut __accounts =
                AdminConfig::try_accounts(__program_id,
                        &mut __remaining_accounts, __ix_data, &mut __bumps,
                        &mut __reallocs)?;
            #[inline(always)]
            unsafe fn __shorten_invariant_lifetime_remaining_accounts<'a,
                'info: 'a>(value: &'a [AccountInfo<'info>])
                -> &'a [AccountInfo<'a>] {
                unsafe { ::core::mem::transmute(value) }
            }
            let result =
                gpu_escrow::set_paused(anchor_lang::context::Context::new(__program_id,
                            unsafe {
                                AdminConfig::__shorten_invariant_lifetime(&mut __accounts)
                            },
                            unsafe {
                                __shorten_invariant_lifetime_remaining_accounts(__remaining_accounts)
                            }, __bumps), paused)?;
            __accounts.exit(__program_id)
        }
        #[inline(never)]
        pub fn propose_admin<'info>(__program_id: &'info Pubkey,
            __accounts: &'info [AccountInfo<'info>], __ix_data: &'info [u8])
            -> anchor_lang::Result<()> {
            ::solana_msg::sol_log("Instruction: ProposeAdmin");
            const _: () =
                {
                    const EXPECTED_COUNT: usize =
                        AdminConfig::__ANCHOR_IX_PARAM_COUNT;
                    const HANDLER_PARAM_COUNT: usize = 1usize;
                    if EXPECTED_COUNT > HANDLER_PARAM_COUNT {
                        {
                            ::core::panicking::panic_fmt(format_args!("#[instruction(...)] on Account `AdminConfig<\'_>` expects MORE args, the ix `propose_admin(...)` has only 1 args."));
                        };
                    }
                };
            const _: fn() =
                ||
                    {
                        let _: fn(&Pubkey) =
                            AdminConfig::__anchor_validate_ix_arg_type_0;
                    };
            let ix =
                instruction::ProposeAdmin::deserialize(&mut &__ix_data[..]).map_err(|_|
                            anchor_lang::error::ErrorCode::InstructionDidNotDeserialize)?;
            let instruction::ProposeAdmin { pending_admin } = ix;
            let mut __bumps =
                <AdminConfig as anchor_lang::Bumps>::Bumps::default();
            let mut __reallocs = ::std::collections::BTreeSet::new();
            let mut __remaining_accounts = __accounts;
            let mut __accounts =
                AdminConfig::try_accounts(__program_id,
                        &mut __remaining_accounts, __ix_data, &mut __bumps,
                        &mut __reallocs)?;
            #[inline(always)]
            unsafe fn __shorten_invariant_lifetime_remaining_accounts<'a,
                'info: 'a>(value: &'a [AccountInfo<'info>])
                -> &'a [AccountInfo<'a>] {
                unsafe { ::core::mem::transmute(value) }
            }
            let result =
                gpu_escrow::propose_admin(anchor_lang::context::Context::new(__program_id,
                            unsafe {
                                AdminConfig::__shorten_invariant_lifetime(&mut __accounts)
                            },
                            unsafe {
                                __shorten_invariant_lifetime_remaining_accounts(__remaining_accounts)
                            }, __bumps), pending_admin)?;
            __accounts.exit(__program_id)
        }
        #[inline(never)]
        pub fn accept_admin<'info>(__program_id: &'info Pubkey,
            __accounts: &'info [AccountInfo<'info>], __ix_data: &'info [u8])
            -> anchor_lang::Result<()> {
            ::solana_msg::sol_log("Instruction: AcceptAdmin");
            const _: () =
                {
                    const EXPECTED_COUNT: usize =
                        AcceptAdmin::__ANCHOR_IX_PARAM_COUNT;
                    const HANDLER_PARAM_COUNT: usize = 0usize;
                    if EXPECTED_COUNT > HANDLER_PARAM_COUNT {
                        {
                            ::core::panicking::panic_fmt(format_args!("#[instruction(...)] on Account `AcceptAdmin<\'_>` expects MORE args, the ix `accept_admin(...)` has only 0 args."));
                        };
                    }
                };
            let ix =
                instruction::AcceptAdmin::deserialize(&mut &__ix_data[..]).map_err(|_|
                            anchor_lang::error::ErrorCode::InstructionDidNotDeserialize)?;
            let instruction::AcceptAdmin = ix;
            let mut __bumps =
                <AcceptAdmin as anchor_lang::Bumps>::Bumps::default();
            let mut __reallocs = ::std::collections::BTreeSet::new();
            let mut __remaining_accounts = __accounts;
            let mut __accounts =
                AcceptAdmin::try_accounts(__program_id,
                        &mut __remaining_accounts, __ix_data, &mut __bumps,
                        &mut __reallocs)?;
            #[inline(always)]
            unsafe fn __shorten_invariant_lifetime_remaining_accounts<'a,
                'info: 'a>(value: &'a [AccountInfo<'info>])
                -> &'a [AccountInfo<'a>] {
                unsafe { ::core::mem::transmute(value) }
            }
            let result =
                gpu_escrow::accept_admin(anchor_lang::context::Context::new(__program_id,
                            unsafe {
                                AcceptAdmin::__shorten_invariant_lifetime(&mut __accounts)
                            },
                            unsafe {
                                __shorten_invariant_lifetime_remaining_accounts(__remaining_accounts)
                            }, __bumps))?;
            __accounts.exit(__program_id)
        }
        #[inline(never)]
        pub fn open<'info>(__program_id: &'info Pubkey,
            __accounts: &'info [AccountInfo<'info>], __ix_data: &'info [u8])
            -> anchor_lang::Result<()> {
            ::solana_msg::sol_log("Instruction: Open");
            const _: () =
                {
                    const EXPECTED_COUNT: usize = Open::__ANCHOR_IX_PARAM_COUNT;
                    const HANDLER_PARAM_COUNT: usize = 4usize;
                    if EXPECTED_COUNT > HANDLER_PARAM_COUNT {
                        {
                            ::core::panicking::panic_fmt(format_args!("#[instruction(...)] on Account `Open<\'_>` expects MORE args, the ix `open(...)` has only 4 args."));
                        };
                    }
                };
            const _: fn() =
                ||
                    {
                        let _: fn(&[u8; 32]) =
                            Open::__anchor_validate_ix_arg_type_0;
                    };
            const _: fn() =
                ||
                    {
                        let _: fn(&u64) = Open::__anchor_validate_ix_arg_type_1;
                    };
            const _: fn() =
                ||
                    {
                        let _: fn(&u32) = Open::__anchor_validate_ix_arg_type_2;
                    };
            const _: fn() =
                ||
                    {
                        let _: fn(&i64) = Open::__anchor_validate_ix_arg_type_3;
                    };
            let ix =
                instruction::Open::deserialize(&mut &__ix_data[..]).map_err(|_|
                            anchor_lang::error::ErrorCode::InstructionDidNotDeserialize)?;
            let instruction::Open {
                    booking, amount, expected_seconds, expires_at } = ix;
            let mut __bumps = <Open as anchor_lang::Bumps>::Bumps::default();
            let mut __reallocs = ::std::collections::BTreeSet::new();
            let mut __remaining_accounts = __accounts;
            let mut __accounts =
                Open::try_accounts(__program_id, &mut __remaining_accounts,
                        __ix_data, &mut __bumps, &mut __reallocs)?;
            #[inline(always)]
            unsafe fn __shorten_invariant_lifetime_remaining_accounts<'a,
                'info: 'a>(value: &'a [AccountInfo<'info>])
                -> &'a [AccountInfo<'a>] {
                unsafe { ::core::mem::transmute(value) }
            }
            let result =
                gpu_escrow::open(anchor_lang::context::Context::new(__program_id,
                            unsafe {
                                Open::__shorten_invariant_lifetime(&mut __accounts)
                            },
                            unsafe {
                                __shorten_invariant_lifetime_remaining_accounts(__remaining_accounts)
                            }, __bumps), booking, amount, expected_seconds,
                        expires_at)?;
            __accounts.exit(__program_id)
        }
        #[inline(never)]
        pub fn propose_settlement<'info>(__program_id: &'info Pubkey,
            __accounts: &'info [AccountInfo<'info>], __ix_data: &'info [u8])
            -> anchor_lang::Result<()> {
            ::solana_msg::sol_log("Instruction: ProposeSettlement");
            const _: () =
                {
                    const EXPECTED_COUNT: usize =
                        ProposeSettlement::__ANCHOR_IX_PARAM_COUNT;
                    const HANDLER_PARAM_COUNT: usize = 1usize;
                    if EXPECTED_COUNT > HANDLER_PARAM_COUNT {
                        {
                            ::core::panicking::panic_fmt(format_args!("#[instruction(...)] on Account `ProposeSettlement<\'_>` expects MORE args, the ix `propose_settlement(...)` has only 1 args."));
                        };
                    }
                };
            const _: fn() =
                ||
                    {
                        let _: fn(&u32) =
                            ProposeSettlement::__anchor_validate_ix_arg_type_0;
                    };
            let ix =
                instruction::ProposeSettlement::deserialize(&mut &__ix_data[..]).map_err(|_|
                            anchor_lang::error::ErrorCode::InstructionDidNotDeserialize)?;
            let instruction::ProposeSettlement { valid_seconds } = ix;
            let mut __bumps =
                <ProposeSettlement as anchor_lang::Bumps>::Bumps::default();
            let mut __reallocs = ::std::collections::BTreeSet::new();
            let mut __remaining_accounts = __accounts;
            let mut __accounts =
                ProposeSettlement::try_accounts(__program_id,
                        &mut __remaining_accounts, __ix_data, &mut __bumps,
                        &mut __reallocs)?;
            #[inline(always)]
            unsafe fn __shorten_invariant_lifetime_remaining_accounts<'a,
                'info: 'a>(value: &'a [AccountInfo<'info>])
                -> &'a [AccountInfo<'a>] {
                unsafe { ::core::mem::transmute(value) }
            }
            let result =
                gpu_escrow::propose_settlement(anchor_lang::context::Context::new(__program_id,
                            unsafe {
                                ProposeSettlement::__shorten_invariant_lifetime(&mut __accounts)
                            },
                            unsafe {
                                __shorten_invariant_lifetime_remaining_accounts(__remaining_accounts)
                            }, __bumps), valid_seconds)?;
            __accounts.exit(__program_id)
        }
        #[inline(never)]
        pub fn dispute<'info>(__program_id: &'info Pubkey,
            __accounts: &'info [AccountInfo<'info>], __ix_data: &'info [u8])
            -> anchor_lang::Result<()> {
            ::solana_msg::sol_log("Instruction: Dispute");
            const _: () =
                {
                    const EXPECTED_COUNT: usize =
                        Dispute::__ANCHOR_IX_PARAM_COUNT;
                    const HANDLER_PARAM_COUNT: usize = 0usize;
                    if EXPECTED_COUNT > HANDLER_PARAM_COUNT {
                        {
                            ::core::panicking::panic_fmt(format_args!("#[instruction(...)] on Account `Dispute<\'_>` expects MORE args, the ix `dispute(...)` has only 0 args."));
                        };
                    }
                };
            let ix =
                instruction::Dispute::deserialize(&mut &__ix_data[..]).map_err(|_|
                            anchor_lang::error::ErrorCode::InstructionDidNotDeserialize)?;
            let instruction::Dispute = ix;
            let mut __bumps =
                <Dispute as anchor_lang::Bumps>::Bumps::default();
            let mut __reallocs = ::std::collections::BTreeSet::new();
            let mut __remaining_accounts = __accounts;
            let mut __accounts =
                Dispute::try_accounts(__program_id, &mut __remaining_accounts,
                        __ix_data, &mut __bumps, &mut __reallocs)?;
            #[inline(always)]
            unsafe fn __shorten_invariant_lifetime_remaining_accounts<'a,
                'info: 'a>(value: &'a [AccountInfo<'info>])
                -> &'a [AccountInfo<'a>] {
                unsafe { ::core::mem::transmute(value) }
            }
            let result =
                gpu_escrow::dispute(anchor_lang::context::Context::new(__program_id,
                            unsafe {
                                Dispute::__shorten_invariant_lifetime(&mut __accounts)
                            },
                            unsafe {
                                __shorten_invariant_lifetime_remaining_accounts(__remaining_accounts)
                            }, __bumps))?;
            __accounts.exit(__program_id)
        }
        #[inline(never)]
        pub fn finalize<'info>(__program_id: &'info Pubkey,
            __accounts: &'info [AccountInfo<'info>], __ix_data: &'info [u8])
            -> anchor_lang::Result<()> {
            ::solana_msg::sol_log("Instruction: Finalize");
            const _: () =
                {
                    const EXPECTED_COUNT: usize =
                        Finalize::__ANCHOR_IX_PARAM_COUNT;
                    const HANDLER_PARAM_COUNT: usize = 0usize;
                    if EXPECTED_COUNT > HANDLER_PARAM_COUNT {
                        {
                            ::core::panicking::panic_fmt(format_args!("#[instruction(...)] on Account `Finalize<\'_>` expects MORE args, the ix `finalize(...)` has only 0 args."));
                        };
                    }
                };
            let ix =
                instruction::Finalize::deserialize(&mut &__ix_data[..]).map_err(|_|
                            anchor_lang::error::ErrorCode::InstructionDidNotDeserialize)?;
            let instruction::Finalize = ix;
            let mut __bumps =
                <Finalize as anchor_lang::Bumps>::Bumps::default();
            let mut __reallocs = ::std::collections::BTreeSet::new();
            let mut __remaining_accounts = __accounts;
            let mut __accounts =
                Finalize::try_accounts(__program_id,
                        &mut __remaining_accounts, __ix_data, &mut __bumps,
                        &mut __reallocs)?;
            #[inline(always)]
            unsafe fn __shorten_invariant_lifetime_remaining_accounts<'a,
                'info: 'a>(value: &'a [AccountInfo<'info>])
                -> &'a [AccountInfo<'a>] {
                unsafe { ::core::mem::transmute(value) }
            }
            let result =
                gpu_escrow::finalize(anchor_lang::context::Context::new(__program_id,
                            unsafe {
                                Finalize::__shorten_invariant_lifetime(&mut __accounts)
                            },
                            unsafe {
                                __shorten_invariant_lifetime_remaining_accounts(__remaining_accounts)
                            }, __bumps))?;
            __accounts.exit(__program_id)
        }
        #[inline(never)]
        pub fn resolve_dispute<'info>(__program_id: &'info Pubkey,
            __accounts: &'info [AccountInfo<'info>], __ix_data: &'info [u8])
            -> anchor_lang::Result<()> {
            ::solana_msg::sol_log("Instruction: ResolveDispute");
            const _: () =
                {
                    const EXPECTED_COUNT: usize =
                        ResolveDispute::__ANCHOR_IX_PARAM_COUNT;
                    const HANDLER_PARAM_COUNT: usize = 1usize;
                    if EXPECTED_COUNT > HANDLER_PARAM_COUNT {
                        {
                            ::core::panicking::panic_fmt(format_args!("#[instruction(...)] on Account `ResolveDispute<\'_>` expects MORE args, the ix `resolve_dispute(...)` has only 1 args."));
                        };
                    }
                };
            const _: fn() =
                ||
                    {
                        let _: fn(&u32) =
                            ResolveDispute::__anchor_validate_ix_arg_type_0;
                    };
            let ix =
                instruction::ResolveDispute::deserialize(&mut &__ix_data[..]).map_err(|_|
                            anchor_lang::error::ErrorCode::InstructionDidNotDeserialize)?;
            let instruction::ResolveDispute { valid_seconds } = ix;
            let mut __bumps =
                <ResolveDispute as anchor_lang::Bumps>::Bumps::default();
            let mut __reallocs = ::std::collections::BTreeSet::new();
            let mut __remaining_accounts = __accounts;
            let mut __accounts =
                ResolveDispute::try_accounts(__program_id,
                        &mut __remaining_accounts, __ix_data, &mut __bumps,
                        &mut __reallocs)?;
            #[inline(always)]
            unsafe fn __shorten_invariant_lifetime_remaining_accounts<'a,
                'info: 'a>(value: &'a [AccountInfo<'info>])
                -> &'a [AccountInfo<'a>] {
                unsafe { ::core::mem::transmute(value) }
            }
            let result =
                gpu_escrow::resolve_dispute(anchor_lang::context::Context::new(__program_id,
                            unsafe {
                                ResolveDispute::__shorten_invariant_lifetime(&mut __accounts)
                            },
                            unsafe {
                                __shorten_invariant_lifetime_remaining_accounts(__remaining_accounts)
                            }, __bumps), valid_seconds)?;
            __accounts.exit(__program_id)
        }
        #[inline(never)]
        pub fn refund_expired<'info>(__program_id: &'info Pubkey,
            __accounts: &'info [AccountInfo<'info>], __ix_data: &'info [u8])
            -> anchor_lang::Result<()> {
            ::solana_msg::sol_log("Instruction: RefundExpired");
            const _: () =
                {
                    const EXPECTED_COUNT: usize =
                        RefundExpired::__ANCHOR_IX_PARAM_COUNT;
                    const HANDLER_PARAM_COUNT: usize = 0usize;
                    if EXPECTED_COUNT > HANDLER_PARAM_COUNT {
                        {
                            ::core::panicking::panic_fmt(format_args!("#[instruction(...)] on Account `RefundExpired<\'_>` expects MORE args, the ix `refund_expired(...)` has only 0 args."));
                        };
                    }
                };
            let ix =
                instruction::RefundExpired::deserialize(&mut &__ix_data[..]).map_err(|_|
                            anchor_lang::error::ErrorCode::InstructionDidNotDeserialize)?;
            let instruction::RefundExpired = ix;
            let mut __bumps =
                <RefundExpired as anchor_lang::Bumps>::Bumps::default();
            let mut __reallocs = ::std::collections::BTreeSet::new();
            let mut __remaining_accounts = __accounts;
            let mut __accounts =
                RefundExpired::try_accounts(__program_id,
                        &mut __remaining_accounts, __ix_data, &mut __bumps,
                        &mut __reallocs)?;
            #[inline(always)]
            unsafe fn __shorten_invariant_lifetime_remaining_accounts<'a,
                'info: 'a>(value: &'a [AccountInfo<'info>])
                -> &'a [AccountInfo<'a>] {
                unsafe { ::core::mem::transmute(value) }
            }
            let result =
                gpu_escrow::refund_expired(anchor_lang::context::Context::new(__program_id,
                            unsafe {
                                RefundExpired::__shorten_invariant_lifetime(&mut __accounts)
                            },
                            unsafe {
                                __shorten_invariant_lifetime_remaining_accounts(__remaining_accounts)
                            }, __bumps))?;
            __accounts.exit(__program_id)
        }
    }
}
pub mod gpu_escrow {
    use super::*;
    pub fn initialize_config(ctx: Context<InitializeConfig>, platform: Pubkey,
        oracle: Pubkey) -> Result<()> {
        if !(platform != Pubkey::default() && oracle != Pubkey::default()) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::InvalidAddress.name(),
                            error_code_number: ErrorCode::InvalidAddress.into(),
                            error_msg: ErrorCode::InvalidAddress.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 17u32,
                                    })),
                            compared_values: None,
                        }));
        };
        let c = &mut ctx.accounts.config;
        c.admin = ctx.accounts.admin.key();
        c.platform = platform;
        c.oracle = oracle;
        c.paused = false;
        c.pending_admin = Pubkey::default();
        c.bump = ctx.bumps.config;
        {
            anchor_lang::solana_program::log::sol_log_data(&[&anchor_lang::Event::data(&ConfigInitialized {
                                            admin: c.admin,
                                            platform,
                                            oracle,
                                        })]);
        };
        Ok(())
    }
    pub fn update_config(ctx: Context<AdminConfig>, platform: Pubkey,
        oracle: Pubkey) -> Result<()> {
        if !(platform != Pubkey::default() && oracle != Pubkey::default()) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::InvalidAddress.name(),
                            error_code_number: ErrorCode::InvalidAddress.into(),
                            error_msg: ErrorCode::InvalidAddress.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 30u32,
                                    })),
                            compared_values: None,
                        }));
        };
        let c = &mut ctx.accounts.config;
        c.platform = platform;
        c.oracle = oracle;
        {
            anchor_lang::solana_program::log::sol_log_data(&[&anchor_lang::Event::data(&ConfigUpdated {
                                            platform,
                                            oracle,
                                        })]);
        };
        Ok(())
    }
    pub fn set_paused(ctx: Context<AdminConfig>, paused: bool) -> Result<()> {
        ctx.accounts.config.paused = paused;
        {
            anchor_lang::solana_program::log::sol_log_data(&[&anchor_lang::Event::data(&PauseChanged {
                                            paused,
                                        })]);
        };
        Ok(())
    }
    pub fn propose_admin(ctx: Context<AdminConfig>, pending_admin: Pubkey)
        -> Result<()> {
        if !(pending_admin != Pubkey::default() &&
                        pending_admin != ctx.accounts.config.admin) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::InvalidAddress.name(),
                            error_code_number: ErrorCode::InvalidAddress.into(),
                            error_msg: ErrorCode::InvalidAddress.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 45u32,
                                    })),
                            compared_values: None,
                        }));
        };
        ctx.accounts.config.pending_admin = pending_admin;
        {
            anchor_lang::solana_program::log::sol_log_data(&[&anchor_lang::Event::data(&AdminTransferProposed {
                                            current_admin: ctx.accounts.config.admin,
                                            pending_admin,
                                        })]);
        };
        Ok(())
    }
    pub fn accept_admin(ctx: Context<AcceptAdmin>) -> Result<()> {
        let c = &mut ctx.accounts.config;
        if !(c.pending_admin == ctx.accounts.pending_admin.key()) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::Unauthorized.name(),
                            error_code_number: ErrorCode::Unauthorized.into(),
                            error_msg: ErrorCode::Unauthorized.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 53u32,
                                    })),
                            compared_values: None,
                        }));
        };
        let previous_admin = c.admin;
        c.admin = c.pending_admin;
        c.pending_admin = Pubkey::default();
        {
            anchor_lang::solana_program::log::sol_log_data(&[&anchor_lang::Event::data(&AdminTransferred {
                                            previous_admin,
                                            new_admin: c.admin,
                                        })]);
        };
        Ok(())
    }
    pub fn open(ctx: Context<Open>, booking: [u8; 32], amount: u64,
        expected_seconds: u32, expires_at: i64) -> Result<()> {
        let now = Clock::get()?.unix_timestamp;
        if !(!ctx.accounts.config.paused) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::Paused.name(),
                            error_code_number: ErrorCode::Paused.into(),
                            error_msg: ErrorCode::Paused.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 63u32,
                                    })),
                            compared_values: None,
                        }));
        };
        if !(amount > 0 && expected_seconds > 0 &&
                        expected_seconds <= MAX_BOOKING_SECONDS) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::InvalidInput.name(),
                            error_code_number: ErrorCode::InvalidInput.into(),
                            error_msg: ErrorCode::InvalidInput.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 64u32,
                                    })),
                            compared_values: None,
                        }));
        };
        if !(expires_at > now &&
                        expires_at <=
                            now.checked_add(MAX_EXPIRY_SECONDS).ok_or(ErrorCode::Math)?)
            {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::InvalidExpiry.name(),
                            error_code_number: ErrorCode::InvalidExpiry.into(),
                            error_msg: ErrorCode::InvalidExpiry.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 65u32,
                                    })),
                            compared_values: None,
                        }));
        };
        if !(ctx.accounts.provider.key() != ctx.accounts.buyer.key()) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::SelfBooking.name(),
                            error_code_number: ErrorCode::SelfBooking.into(),
                            error_msg: ErrorCode::SelfBooking.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 66u32,
                                    })),
                            compared_values: None,
                        }));
        };
        let e = &mut ctx.accounts.escrow;
        e.booking = booking;
        e.buyer = ctx.accounts.buyer.key();
        e.provider = ctx.accounts.provider.key();
        e.amount = amount;
        e.expected_seconds = expected_seconds;
        e.valid_seconds = 0;
        e.expires_at = expires_at;
        e.settle_after = 0;
        e.state = EscrowState::Funded as u8;
        e.bump = ctx.bumps.escrow;
        let ix =
            anchor_lang::solana_program::system_instruction::transfer(&ctx.accounts.buyer.key(),
                &e.key(), amount);
        anchor_lang::solana_program::program::invoke(&ix,
                &[ctx.accounts.buyer.to_account_info(), e.to_account_info(),
                            ctx.accounts.system_program.to_account_info()])?;
        {
            anchor_lang::solana_program::log::sol_log_data(&[&anchor_lang::Event::data(&EscrowOpened {
                                            escrow: e.key(),
                                            booking,
                                            buyer: e.buyer,
                                            provider: e.provider,
                                            amount,
                                            expected_seconds,
                                            expires_at,
                                        })]);
        };
        Ok(())
    }
    pub fn propose_settlement(ctx: Context<ProposeSettlement>,
        valid_seconds: u32) -> Result<()> {
        if !(!ctx.accounts.config.paused) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::Paused.name(),
                            error_code_number: ErrorCode::Paused.into(),
                            error_msg: ErrorCode::Paused.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 90u32,
                                    })),
                            compared_values: None,
                        }));
        };
        let e = &mut ctx.accounts.escrow;
        if !(e.state == EscrowState::Funded as u8) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::InvalidState.name(),
                            error_code_number: ErrorCode::InvalidState.into(),
                            error_msg: ErrorCode::InvalidState.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 92u32,
                                    })),
                            compared_values: None,
                        }));
        };
        if !(valid_seconds <= e.expected_seconds) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::InvalidInput.name(),
                            error_code_number: ErrorCode::InvalidInput.into(),
                            error_msg: ErrorCode::InvalidInput.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 93u32,
                                    })),
                            compared_values: None,
                        }));
        };
        e.valid_seconds = valid_seconds;
        e.settle_after =
            Clock::get()?.unix_timestamp.checked_add(DISPUTE_WINDOW_SECONDS).ok_or(ErrorCode::Math)?;
        e.state = EscrowState::SettlementProposed as u8;
        {
            anchor_lang::solana_program::log::sol_log_data(&[&anchor_lang::Event::data(&SettlementProposed {
                                            escrow: e.key(),
                                            valid_seconds,
                                            settle_after: e.settle_after,
                                        })]);
        };
        Ok(())
    }
    pub fn dispute(ctx: Context<Dispute>) -> Result<()> {
        let e = &mut ctx.accounts.escrow;
        if !(e.state == EscrowState::SettlementProposed as u8) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::InvalidState.name(),
                            error_code_number: ErrorCode::InvalidState.into(),
                            error_msg: ErrorCode::InvalidState.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 103u32,
                                    })),
                            compared_values: None,
                        }));
        };
        if !(Clock::get()?.unix_timestamp < e.settle_after) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::DisputeWindowClosed.name(),
                            error_code_number: ErrorCode::DisputeWindowClosed.into(),
                            error_msg: ErrorCode::DisputeWindowClosed.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 104u32,
                                    })),
                            compared_values: None,
                        }));
        };
        e.state = EscrowState::Disputed as u8;
        {
            anchor_lang::solana_program::log::sol_log_data(&[&anchor_lang::Event::data(&EscrowDisputed {
                                            escrow: e.key(),
                                            buyer: e.buyer,
                                        })]);
        };
        Ok(())
    }
    pub fn finalize(ctx: Context<Finalize>) -> Result<()> {
        if !(ctx.accounts.escrow.state ==
                        EscrowState::SettlementProposed as u8) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::InvalidState.name(),
                            error_code_number: ErrorCode::InvalidState.into(),
                            error_msg: ErrorCode::InvalidState.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 111u32,
                                    })),
                            compared_values: None,
                        }));
        };
        if !(Clock::get()?.unix_timestamp >= ctx.accounts.escrow.settle_after)
            {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::TooEarly.name(),
                            error_code_number: ErrorCode::TooEarly.into(),
                            error_msg: ErrorCode::TooEarly.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 112u32,
                                    })),
                            compared_values: None,
                        }));
        };
        let valid_seconds = ctx.accounts.escrow.valid_seconds;
        settle(&mut ctx.accounts.escrow, &ctx.accounts.buyer,
            &ctx.accounts.provider, &ctx.accounts.platform, valid_seconds)
    }
    pub fn resolve_dispute(ctx: Context<ResolveDispute>, valid_seconds: u32)
        -> Result<()> {
        if !(ctx.accounts.escrow.state == EscrowState::Disputed as u8) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::InvalidState.name(),
                            error_code_number: ErrorCode::InvalidState.into(),
                            error_msg: ErrorCode::InvalidState.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 121u32,
                                    })),
                            compared_values: None,
                        }));
        };
        if !(valid_seconds <= ctx.accounts.escrow.expected_seconds) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::InvalidInput.name(),
                            error_code_number: ErrorCode::InvalidInput.into(),
                            error_msg: ErrorCode::InvalidInput.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 122u32,
                                    })),
                            compared_values: None,
                        }));
        };
        settle(&mut ctx.accounts.escrow, &ctx.accounts.buyer,
            &ctx.accounts.provider, &ctx.accounts.platform, valid_seconds)
    }
    pub fn refund_expired(ctx: Context<RefundExpired>) -> Result<()> {
        let e = &mut ctx.accounts.escrow;
        if !(e.state == EscrowState::Funded as u8) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::InvalidState.name(),
                            error_code_number: ErrorCode::InvalidState.into(),
                            error_msg: ErrorCode::InvalidState.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 128u32,
                                    })),
                            compared_values: None,
                        }));
        };
        if !(Clock::get()?.unix_timestamp >= e.expires_at) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                            error_name: ErrorCode::TooEarly.name(),
                            error_code_number: ErrorCode::TooEarly.into(),
                            error_msg: ErrorCode::TooEarly.to_string(),
                            error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                        filename: "programs/gpu_escrow/src/lib.rs",
                                        line: 129u32,
                                    })),
                            compared_values: None,
                        }));
        };
        let amount = e.amount;
        transfer_lamports(&e.to_account_info(),
                &ctx.accounts.buyer.to_account_info(), amount)?;
        e.state = EscrowState::Refunded as u8;
        {
            anchor_lang::solana_program::log::sol_log_data(&[&anchor_lang::Event::data(&EscrowRefunded {
                                            escrow: e.key(),
                                            buyer: e.buyer,
                                            amount,
                                        })]);
        };
        Ok(())
    }
}
#[doc = r" An Anchor generated module containing the program's set of"]
#[doc =
r" instructions, where each method handler in the `#[program]` mod is"]
#[doc = r" associated with a struct defining the input arguments to the"]
#[doc =
r" method. These should be used directly, when one wants to serialize"]
#[doc = r" Anchor instruction data, for example, when specifying"]
#[doc = r" instructions on a client."]
pub mod instruction {
    use super::*;
    #[doc = r" Instruction."]
    pub struct InitializeConfig {
        pub platform: Pubkey,
        pub oracle: Pubkey,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for InitializeConfig
        {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.platform,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.oracle,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::de::BorshDeserialize for
        InitializeConfig {
        fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
                &mut __R)
            ->
                ::core::result::Result<Self,
                anchor_lang::prelude::borsh::io::Error> {
            Ok(Self {
                    platform: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                    oracle: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                })
        }
    }
    #[automatically_derived]
    impl ::core::clone::Clone for InitializeConfig {
        #[inline]
        fn clone(&self) -> InitializeConfig {
            InitializeConfig {
                platform: ::core::clone::Clone::clone(&self.platform),
                oracle: ::core::clone::Clone::clone(&self.oracle),
            }
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for InitializeConfig {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field2_finish(f,
                "InitializeConfig", "platform", &self.platform, "oracle",
                &&self.oracle)
        }
    }
    impl anchor_lang::Discriminator for InitializeConfig {
        const DISCRIMINATOR: &'static [u8] =
            &[208, 127, 21, 1, 194, 190, 196, 70];
    }
    impl anchor_lang::InstructionData for InitializeConfig {}
    impl anchor_lang::Owner for InitializeConfig {
        fn owner() -> Pubkey { ID }
    }
    #[doc = r" Instruction."]
    pub struct UpdateConfig {
        pub platform: Pubkey,
        pub oracle: Pubkey,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for UpdateConfig {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.platform,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.oracle,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::de::BorshDeserialize for UpdateConfig {
        fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
                &mut __R)
            ->
                ::core::result::Result<Self,
                anchor_lang::prelude::borsh::io::Error> {
            Ok(Self {
                    platform: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                    oracle: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                })
        }
    }
    #[automatically_derived]
    impl ::core::clone::Clone for UpdateConfig {
        #[inline]
        fn clone(&self) -> UpdateConfig {
            UpdateConfig {
                platform: ::core::clone::Clone::clone(&self.platform),
                oracle: ::core::clone::Clone::clone(&self.oracle),
            }
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for UpdateConfig {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field2_finish(f,
                "UpdateConfig", "platform", &self.platform, "oracle",
                &&self.oracle)
        }
    }
    impl anchor_lang::Discriminator for UpdateConfig {
        const DISCRIMINATOR: &'static [u8] =
            &[29, 158, 252, 191, 10, 83, 219, 99];
    }
    impl anchor_lang::InstructionData for UpdateConfig {}
    impl anchor_lang::Owner for UpdateConfig {
        fn owner() -> Pubkey { ID }
    }
    #[doc = r" Instruction."]
    pub struct SetPaused {
        pub paused: bool,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for SetPaused {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.paused,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::de::BorshDeserialize for SetPaused {
        fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
                &mut __R)
            ->
                ::core::result::Result<Self,
                anchor_lang::prelude::borsh::io::Error> {
            Ok(Self {
                    paused: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                })
        }
    }
    #[automatically_derived]
    impl ::core::clone::Clone for SetPaused {
        #[inline]
        fn clone(&self) -> SetPaused {
            SetPaused { paused: ::core::clone::Clone::clone(&self.paused) }
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for SetPaused {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field1_finish(f, "SetPaused",
                "paused", &&self.paused)
        }
    }
    impl anchor_lang::Discriminator for SetPaused {
        const DISCRIMINATOR: &'static [u8] =
            &[91, 60, 125, 192, 176, 225, 166, 218];
    }
    impl anchor_lang::InstructionData for SetPaused {}
    impl anchor_lang::Owner for SetPaused {
        fn owner() -> Pubkey { ID }
    }
    #[doc = r" Instruction."]
    pub struct ProposeAdmin {
        pub pending_admin: Pubkey,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for ProposeAdmin {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.pending_admin,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::de::BorshDeserialize for ProposeAdmin {
        fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
                &mut __R)
            ->
                ::core::result::Result<Self,
                anchor_lang::prelude::borsh::io::Error> {
            Ok(Self {
                    pending_admin: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                })
        }
    }
    #[automatically_derived]
    impl ::core::clone::Clone for ProposeAdmin {
        #[inline]
        fn clone(&self) -> ProposeAdmin {
            ProposeAdmin {
                pending_admin: ::core::clone::Clone::clone(&self.pending_admin),
            }
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for ProposeAdmin {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field1_finish(f,
                "ProposeAdmin", "pending_admin", &&self.pending_admin)
        }
    }
    impl anchor_lang::Discriminator for ProposeAdmin {
        const DISCRIMINATOR: &'static [u8] =
            &[121, 214, 199, 212, 87, 39, 117, 234];
    }
    impl anchor_lang::InstructionData for ProposeAdmin {}
    impl anchor_lang::Owner for ProposeAdmin {
        fn owner() -> Pubkey { ID }
    }
    #[doc = r" Instruction."]
    pub struct AcceptAdmin;
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for AcceptAdmin {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            Ok(())
        }
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::de::BorshDeserialize for AcceptAdmin {
        fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
                &mut __R)
            ->
                ::core::result::Result<Self,
                anchor_lang::prelude::borsh::io::Error> {
            Ok(Self {})
        }
    }
    #[automatically_derived]
    impl ::core::clone::Clone for AcceptAdmin {
        #[inline]
        fn clone(&self) -> AcceptAdmin { AcceptAdmin }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for AcceptAdmin {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::write_str(f, "AcceptAdmin")
        }
    }
    impl anchor_lang::Discriminator for AcceptAdmin {
        const DISCRIMINATOR: &'static [u8] =
            &[112, 42, 45, 90, 116, 181, 13, 170];
    }
    impl anchor_lang::InstructionData for AcceptAdmin {}
    impl anchor_lang::Owner for AcceptAdmin {
        fn owner() -> Pubkey { ID }
    }
    #[doc = r" Instruction."]
    pub struct Open {
        pub booking: [u8; 32],
        pub amount: u64,
        pub expected_seconds: u32,
        pub expires_at: i64,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for Open {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.booking,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.amount,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.expected_seconds,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.expires_at,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::de::BorshDeserialize for Open {
        fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
                &mut __R)
            ->
                ::core::result::Result<Self,
                anchor_lang::prelude::borsh::io::Error> {
            Ok(Self {
                    booking: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                    amount: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                    expected_seconds: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                    expires_at: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                })
        }
    }
    #[automatically_derived]
    impl ::core::clone::Clone for Open {
        #[inline]
        fn clone(&self) -> Open {
            Open {
                booking: ::core::clone::Clone::clone(&self.booking),
                amount: ::core::clone::Clone::clone(&self.amount),
                expected_seconds: ::core::clone::Clone::clone(&self.expected_seconds),
                expires_at: ::core::clone::Clone::clone(&self.expires_at),
            }
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for Open {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field4_finish(f, "Open",
                "booking", &self.booking, "amount", &self.amount,
                "expected_seconds", &self.expected_seconds, "expires_at",
                &&self.expires_at)
        }
    }
    impl anchor_lang::Discriminator for Open {
        const DISCRIMINATOR: &'static [u8] =
            &[228, 220, 155, 71, 199, 189, 60, 45];
    }
    impl anchor_lang::InstructionData for Open {}
    impl anchor_lang::Owner for Open {
        fn owner() -> Pubkey { ID }
    }
    #[doc = r" Instruction."]
    pub struct ProposeSettlement {
        pub valid_seconds: u32,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for
        ProposeSettlement {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.valid_seconds,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::de::BorshDeserialize for
        ProposeSettlement {
        fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
                &mut __R)
            ->
                ::core::result::Result<Self,
                anchor_lang::prelude::borsh::io::Error> {
            Ok(Self {
                    valid_seconds: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                })
        }
    }
    #[automatically_derived]
    impl ::core::clone::Clone for ProposeSettlement {
        #[inline]
        fn clone(&self) -> ProposeSettlement {
            ProposeSettlement {
                valid_seconds: ::core::clone::Clone::clone(&self.valid_seconds),
            }
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for ProposeSettlement {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field1_finish(f,
                "ProposeSettlement", "valid_seconds", &&self.valid_seconds)
        }
    }
    impl anchor_lang::Discriminator for ProposeSettlement {
        const DISCRIMINATOR: &'static [u8] =
            &[228, 149, 56, 61, 137, 43, 106, 25];
    }
    impl anchor_lang::InstructionData for ProposeSettlement {}
    impl anchor_lang::Owner for ProposeSettlement {
        fn owner() -> Pubkey { ID }
    }
    #[doc = r" Instruction."]
    pub struct Dispute;
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for Dispute {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            Ok(())
        }
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::de::BorshDeserialize for Dispute {
        fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
                &mut __R)
            ->
                ::core::result::Result<Self,
                anchor_lang::prelude::borsh::io::Error> {
            Ok(Self {})
        }
    }
    #[automatically_derived]
    impl ::core::clone::Clone for Dispute {
        #[inline]
        fn clone(&self) -> Dispute { Dispute }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for Dispute {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::write_str(f, "Dispute")
        }
    }
    impl anchor_lang::Discriminator for Dispute {
        const DISCRIMINATOR: &'static [u8] =
            &[216, 92, 128, 146, 202, 85, 135, 73];
    }
    impl anchor_lang::InstructionData for Dispute {}
    impl anchor_lang::Owner for Dispute {
        fn owner() -> Pubkey { ID }
    }
    #[doc = r" Instruction."]
    pub struct Finalize;
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for Finalize {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            Ok(())
        }
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::de::BorshDeserialize for Finalize {
        fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
                &mut __R)
            ->
                ::core::result::Result<Self,
                anchor_lang::prelude::borsh::io::Error> {
            Ok(Self {})
        }
    }
    #[automatically_derived]
    impl ::core::clone::Clone for Finalize {
        #[inline]
        fn clone(&self) -> Finalize { Finalize }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for Finalize {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::write_str(f, "Finalize")
        }
    }
    impl anchor_lang::Discriminator for Finalize {
        const DISCRIMINATOR: &'static [u8] =
            &[171, 61, 218, 56, 127, 115, 12, 217];
    }
    impl anchor_lang::InstructionData for Finalize {}
    impl anchor_lang::Owner for Finalize {
        fn owner() -> Pubkey { ID }
    }
    #[doc = r" Instruction."]
    pub struct ResolveDispute {
        pub valid_seconds: u32,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for ResolveDispute {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.valid_seconds,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::de::BorshDeserialize for ResolveDispute
        {
        fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
                &mut __R)
            ->
                ::core::result::Result<Self,
                anchor_lang::prelude::borsh::io::Error> {
            Ok(Self {
                    valid_seconds: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                })
        }
    }
    #[automatically_derived]
    impl ::core::clone::Clone for ResolveDispute {
        #[inline]
        fn clone(&self) -> ResolveDispute {
            ResolveDispute {
                valid_seconds: ::core::clone::Clone::clone(&self.valid_seconds),
            }
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for ResolveDispute {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field1_finish(f,
                "ResolveDispute", "valid_seconds", &&self.valid_seconds)
        }
    }
    impl anchor_lang::Discriminator for ResolveDispute {
        const DISCRIMINATOR: &'static [u8] =
            &[231, 6, 202, 6, 96, 103, 12, 230];
    }
    impl anchor_lang::InstructionData for ResolveDispute {}
    impl anchor_lang::Owner for ResolveDispute {
        fn owner() -> Pubkey { ID }
    }
    #[doc = r" Instruction."]
    pub struct RefundExpired;
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for RefundExpired {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            Ok(())
        }
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::de::BorshDeserialize for RefundExpired {
        fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
                &mut __R)
            ->
                ::core::result::Result<Self,
                anchor_lang::prelude::borsh::io::Error> {
            Ok(Self {})
        }
    }
    #[automatically_derived]
    impl ::core::clone::Clone for RefundExpired {
        #[inline]
        fn clone(&self) -> RefundExpired { RefundExpired }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for RefundExpired {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::write_str(f, "RefundExpired")
        }
    }
    impl anchor_lang::Discriminator for RefundExpired {
        const DISCRIMINATOR: &'static [u8] =
            &[118, 153, 164, 244, 40, 128, 242, 250];
    }
    impl anchor_lang::InstructionData for RefundExpired {}
    impl anchor_lang::Owner for RefundExpired {
        fn owner() -> Pubkey { ID }
    }
}
#[doc = r" An Anchor generated module, providing a set of structs"]
#[doc = r" mirroring the structs deriving `Accounts`, where each field is"]
#[doc = r" a `Pubkey`. This is useful for specifying accounts for a client."]
pub mod accounts {
    pub use crate::__client_accounts_initialize_config::*;
    pub use crate::__client_accounts_dispute::*;
    pub use crate::__client_accounts_accept_admin::*;
    pub use crate::__client_accounts_resolve_dispute::*;
    pub use crate::__client_accounts_admin_config::*;
    pub use crate::__client_accounts_refund_expired::*;
    pub use crate::__client_accounts_open::*;
    pub use crate::__client_accounts_propose_settlement::*;
    pub use crate::__client_accounts_finalize::*;
}
fn settle<'info>(e: &mut Account<'info, Escrow>,
    buyer: &UncheckedAccount<'info>, provider: &UncheckedAccount<'info>,
    platform: &UncheckedAccount<'info>, valid_seconds: u32) -> Result<()> {
    let (payable, platform_amount, provider_amount, refund) =
        settlement_amounts(e.amount, valid_seconds, e.expected_seconds)?;
    transfer_lamports(&e.to_account_info(), &provider.to_account_info(),
            provider_amount)?;
    transfer_lamports(&e.to_account_info(), &platform.to_account_info(),
            platform_amount)?;
    transfer_lamports(&e.to_account_info(), &buyer.to_account_info(),
            refund)?;
    e.valid_seconds = valid_seconds;
    e.state = EscrowState::Settled as u8;
    {
        anchor_lang::solana_program::log::sol_log_data(&[&anchor_lang::Event::data(&EscrowSettled {
                                        escrow: e.key(),
                                        payable,
                                        platform_amount,
                                        provider_amount,
                                        refund,
                                        valid_seconds,
                                    })]);
    };
    Ok(())
}
fn settlement_amounts(amount: u64, valid_seconds: u32, expected_seconds: u32)
    -> Result<(u64, u64, u64, u64)> {
    if !(expected_seconds > 0 && valid_seconds <= expected_seconds) {
        return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                        error_name: ErrorCode::InvalidInput.name(),
                        error_code_number: ErrorCode::InvalidInput.into(),
                        error_msg: ErrorCode::InvalidInput.to_string(),
                        error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                    filename: "programs/gpu_escrow/src/lib.rs",
                                    line: 156u32,
                                })),
                        compared_values: None,
                    }));
    };
    let availability =
        (valid_seconds as
                                u128).checked_mul(BPS as u128).ok_or(ErrorCode::Math)? /
            expected_seconds as u128;
    let payable =
        if availability >= FULL_PAY_THRESHOLD_BPS as u128 {
            amount
        } else {
            ((amount as
                                            u128).checked_mul(valid_seconds as
                                        u128).ok_or(ErrorCode::Math)? / expected_seconds as u128) as
                u64
        };
    let platform_amount =
        ((payable as
                                        u128).checked_mul(COMMISSION_BPS as
                                    u128).ok_or(ErrorCode::Math)? / BPS as u128) as u64;
    let provider_amount =
        payable.checked_sub(platform_amount).ok_or(ErrorCode::Math)?;
    let refund = amount.checked_sub(payable).ok_or(ErrorCode::Math)?;
    Ok((payable, platform_amount, provider_amount, refund))
}
fn transfer_lamports(from: &AccountInfo, to: &AccountInfo, amount: u64)
    -> Result<()> {
    if amount == 0 { return Ok(()); }
    **from.try_borrow_mut_lamports()? =
        from.lamports().checked_sub(amount).ok_or(ErrorCode::Math)?;
    **to.try_borrow_mut_lamports()? =
        to.lamports().checked_add(amount).ok_or(ErrorCode::Math)?;
    Ok(())
}
pub struct InitializeConfig<'info> {
    #[account(mut)]
    pub admin: Signer<'info>,
    #[account(init, payer = admin, space = 8 + Config::INIT_SPACE, seeds =
    [b"config"], bump)]
    pub config: Account<'info, Config>,
    pub system_program: Program<'info, System>,
}
#[automatically_derived]
impl<'info> InitializeConfig<'info> where 'info: 'info {
    #[doc(hidden)]
    pub const __ANCHOR_IX_PARAM_COUNT: usize = 0;
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_0<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_1<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_2<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_3<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_4<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_5<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_6<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_7<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_8<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_9<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_10<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_11<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_12<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_13<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_14<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_15<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_16<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_17<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_18<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_19<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_20<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_21<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_22<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_23<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_24<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_25<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_26<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_27<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_28<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_29<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_30<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_31<__T>(_arg: &__T) {}
}
#[automatically_derived]
impl<'info> anchor_lang::Accounts<'info, InitializeConfigBumps> for
    InitializeConfig<'info> where 'info: 'info {
    #[inline(never)]
    fn try_accounts(__program_id:
            &anchor_lang::solana_program::pubkey::Pubkey,
        __accounts:
            &mut &'info [anchor_lang::solana_program::account_info::AccountInfo<'info>],
        __ix_data: &[u8], __bumps: &mut InitializeConfigBumps,
        __reallocs:
            &mut ::std::collections::BTreeSet<anchor_lang::solana_program::pubkey::Pubkey>)
        -> anchor_lang::Result<Self> {
        let admin: Signer =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("admin"))?;
        if __accounts.is_empty() {
            return Err(anchor_lang::error::ErrorCode::AccountNotEnoughKeys.into());
        }
        let config = &__accounts[0];
        *__accounts = &__accounts[1..];
        let system_program:
                anchor_lang::accounts::program::Program<'info, System> =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e|
                        e.with_account_name("system_program"))?;
        let __anchor_rent = Rent::get()?;
        let (__pda_address, __bump) =
            Pubkey::find_program_address(&[b"config"], __program_id);
        __bumps.config = __bump;
        if config.key() != __pda_address {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("config").with_pubkeys((config.key(),
                            __pda_address)));
        }
        let config =
            ({

                            #[inline(never)]
                            ||
                                {
                                    let actual_field = AsRef::<AccountInfo>::as_ref(&config);
                                    let actual_owner = actual_field.owner;
                                    let space = 8 + Config::INIT_SPACE;
                                    let pa: anchor_lang::accounts::account::Account<Config> =
                                        if !false ||
                                                actual_owner ==
                                                    &anchor_lang::solana_program::system_program::ID {
                                            let __current_lamports = config.lamports();
                                            if __current_lamports == 0 {
                                                let space = space;
                                                let lamports = __anchor_rent.minimum_balance(space);
                                                let cpi_accounts =
                                                    anchor_lang::system_program::CreateAccount {
                                                        from: admin.to_account_info(),
                                                        to: config.to_account_info(),
                                                    };
                                                let cpi_context =
                                                    anchor_lang::context::CpiContext::new(system_program.key(),
                                                        cpi_accounts);
                                                anchor_lang::system_program::create_account(cpi_context.with_signer(&[&[b"config",
                                                                                        &[__bump][..]][..]]), lamports, space as u64,
                                                        __program_id)?;
                                            } else {
                                                if admin.key() == config.key() {
                                                    return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                                                                        error_name: anchor_lang::error::ErrorCode::TryingToInitPayerAsProgramAccount.name(),
                                                                        error_code_number: anchor_lang::error::ErrorCode::TryingToInitPayerAsProgramAccount.into(),
                                                                        error_msg: anchor_lang::error::ErrorCode::TryingToInitPayerAsProgramAccount.to_string(),
                                                                        error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                                                                    filename: "programs/gpu_escrow/src/lib.rs",
                                                                                    line: 176u32,
                                                                                })),
                                                                        compared_values: None,
                                                                    }).with_pubkeys((admin.key(), config.key())));
                                                };
                                                let required_lamports =
                                                    __anchor_rent.minimum_balance(space).max(1).saturating_sub(__current_lamports);
                                                let cpi_accounts =
                                                    anchor_lang::system_program::CreateAccountAllowPrefund {
                                                        from: admin.to_account_info(),
                                                        to: config.to_account_info(),
                                                    };
                                                let cpi_context =
                                                    anchor_lang::context::CpiContext::new(system_program.key(),
                                                        cpi_accounts);
                                                anchor_lang::system_program::create_account_allow_prefund(cpi_context.with_signer(&[&[b"config",
                                                                                        &[__bump][..]][..]]), required_lamports, space as u64,
                                                        __program_id)?;
                                            }
                                            match anchor_lang::accounts::account::Account::try_from_unchecked(&config)
                                                {
                                                Ok(val) => val,
                                                Err(e) => return Err(e.with_account_name("config")),
                                            }
                                        } else {
                                            match anchor_lang::accounts::account::Account::try_from(&config)
                                                {
                                                Ok(val) => val,
                                                Err(e) => return Err(e.with_account_name("config")),
                                            }
                                        };
                                    if false {
                                        if space != actual_field.data_len() {
                                            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSpace).with_account_name("config").with_values((space,
                                                            actual_field.data_len())));
                                        }
                                        if actual_owner != __program_id {
                                            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintOwner).with_account_name("config").with_pubkeys((*actual_owner,
                                                            *__program_id)));
                                        }
                                        {
                                            let required_lamports =
                                                __anchor_rent.minimum_balance(space);
                                            if anchor_lang::Lamports::get_lamports(actual_field) <
                                                    required_lamports {
                                                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintRentExempt).with_account_name("config"));
                                            }
                                        }
                                    }
                                    Ok(pa)
                                }
                        })()?;
        if !AsRef::<AccountInfo>::as_ref(&config).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("config"));
        }
        if !__anchor_rent.is_exempt(config.to_account_info().lamports(),
                    config.to_account_info().try_data_len()?) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintRentExempt).with_account_name("config"));
        }
        if !AsRef::<AccountInfo>::as_ref(&admin).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("admin"));
        }
        Ok(InitializeConfig { admin, config, system_program })
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountInfos<'info> for InitializeConfig<'info>
    where 'info: 'info {
    fn to_account_infos(&self)
        ->
            Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
        let mut account_infos = ::alloc::vec::Vec::new();
        account_infos.extend(self.admin.to_account_infos());
        account_infos.extend(self.config.to_account_infos());
        account_infos.extend(self.system_program.to_account_infos());
        account_infos
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountMetas for InitializeConfig<'info> {
    fn to_account_metas(&self, is_signer: Option<bool>)
        -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
        let mut account_metas = ::alloc::vec::Vec::new();
        account_metas.extend(self.admin.to_account_metas(None));
        account_metas.extend(self.config.to_account_metas(None));
        account_metas.extend(self.system_program.to_account_metas(None));
        account_metas
    }
}
#[automatically_derived]
impl<'info> anchor_lang::AccountsExit<'info> for InitializeConfig<'info> where
    'info: 'info {
    fn exit(&self, program_id: &anchor_lang::solana_program::pubkey::Pubkey)
        -> anchor_lang::Result<()> {
        anchor_lang::AccountsExit::exit(&self.admin,
                    program_id).map_err(|e| e.with_account_name("admin"))?;
        anchor_lang::AccountsExit::exit(&self.config,
                    program_id).map_err(|e| e.with_account_name("config"))?;
        Ok(())
    }
}
#[automatically_derived]
impl<'info> anchor_lang::DuplicateMutableAccountKeys for
    InitializeConfig<'info> where 'info: 'info {
    fn duplicate_mutable_account_keys(&self)
        -> Vec<anchor_lang::solana_program::pubkey::Pubkey> {
        let mut keys = Vec::new();
        keys
    }
}
#[automatically_derived]
impl<'info> InitializeConfig<'info> where 'info: 'info {
    #[doc(hidden)]
    #[inline(always)]
    pub unsafe fn __shorten_invariant_lifetime<'__a,
        '__info: '__a>(value: &'__a mut InitializeConfig<'__info>)
        -> &'__a mut InitializeConfig<'__a> {
        unsafe { ::core::mem::transmute(value) }
    }
}
pub struct InitializeConfigBumps {
    pub config: u8,
}
#[automatically_derived]
impl ::core::fmt::Debug for InitializeConfigBumps {
    #[inline]
    fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
        ::core::fmt::Formatter::debug_struct_field1_finish(f,
            "InitializeConfigBumps", "config", &&self.config)
    }
}
#[automatically_derived]
#[doc(hidden)]
unsafe impl ::core::clone::TrivialClone for InitializeConfigBumps { }
#[automatically_derived]
impl ::core::clone::Clone for InitializeConfigBumps {
    #[inline]
    fn clone(&self) -> InitializeConfigBumps {
        let _: ::core::clone::AssertParamIsClone<u8>;
        *self
    }
}
#[automatically_derived]
impl ::core::marker::Copy for InitializeConfigBumps { }
impl Default for InitializeConfigBumps {
    fn default() -> Self { InitializeConfigBumps { config: u8::MAX } }
}
impl<'info> anchor_lang::Bumps for InitializeConfig<'info> where 'info: 'info
    {
    type Bumps = InitializeConfigBumps;
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a struct for a given"]
#[doc =
r" `#[derive(Accounts)]` implementation, where each field is a Pubkey,"]
#[doc = r" instead of an `AccountInfo`. This is useful for clients that want"]
#[doc = r" to generate a list of accounts, without explicitly knowing the"]
#[doc = r" order all the fields should be in."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" `accounts` module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __client_accounts_initialize_config {
    use super::*;
    use anchor_lang::prelude::borsh;
    #[doc = " Generated client accounts for [`InitializeConfig`]."]
    pub struct InitializeConfig {
        pub admin: Pubkey,
        pub config: Pubkey,
        pub system_program: Pubkey,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for InitializeConfig
        {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.admin,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.config,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.system_program,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for InitializeConfig {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field3_finish(f,
                "InitializeConfig", "admin", &self.admin, "config",
                &self.config, "system_program", &&self.system_program)
        }
    }
    #[automatically_derived]
    impl ::core::default::Default for InitializeConfig {
        #[inline]
        fn default() -> InitializeConfig {
            InitializeConfig {
                admin: ::core::default::Default::default(),
                config: ::core::default::Default::default(),
                system_program: ::core::default::Default::default(),
            }
        }
    }
    #[automatically_derived]
    impl ::core::marker::Copy for InitializeConfig { }
    #[automatically_derived]
    #[doc(hidden)]
    unsafe impl ::core::clone::TrivialClone for InitializeConfig { }
    #[automatically_derived]
    impl ::core::clone::Clone for InitializeConfig {
        #[inline]
        fn clone(&self) -> InitializeConfig {
            let _: ::core::clone::AssertParamIsClone<Pubkey>;
            *self
        }
    }
    #[automatically_derived]
    impl anchor_lang::ToAccountMetas for InitializeConfig {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.admin,
                    is_signer.unwrap_or(true)));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.config,
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(self.system_program,
                    false));
            account_metas
        }
    }
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a CPI struct for a given"]
#[doc = r" `#[derive(Accounts)]` implementation, where each field is an"]
#[doc = r" AccountInfo."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" [`cpi::accounts`] module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __cpi_client_accounts_initialize_config {
    use super::*;
    #[doc = " Generated CPI struct of the accounts for [`InitializeConfig`]."]
    pub struct InitializeConfig<'info> {
        pub admin: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub config: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub system_program: anchor_lang::solana_program::account_info::AccountInfo<'info>,
    }
    #[automatically_derived]
    impl<'info> ::core::fmt::Debug for InitializeConfig<'info> {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field3_finish(f,
                "InitializeConfig", "admin", &self.admin, "config",
                &self.config, "system_program", &&self.system_program)
        }
    }
    #[automatically_derived]
    impl<'info> ::core::clone::Clone for InitializeConfig<'info> {
        #[inline]
        fn clone(&self) -> InitializeConfig<'info> {
            InitializeConfig {
                admin: ::core::clone::Clone::clone(&self.admin),
                config: ::core::clone::Clone::clone(&self.config),
                system_program: ::core::clone::Clone::clone(&self.system_program),
            }
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountMetas for InitializeConfig<'info> {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.admin),
                    is_signer.unwrap_or(true)));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.config),
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(anchor_lang::Key::key(&self.system_program),
                    false));
            account_metas
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountInfos<'info> for InitializeConfig<'info>
        {
        fn to_account_infos(&self)
            ->
                Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
            let mut account_infos = ::alloc::vec::Vec::new();
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.admin));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.config));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.system_program));
            account_infos
        }
    }
}
pub struct AdminConfig<'info> {
    pub admin: Signer<'info>,
    #[account(mut, seeds = [b"config"], bump = config.bump, has_one = admin)]
    pub config: Account<'info, Config>,
}
#[automatically_derived]
impl<'info> AdminConfig<'info> where 'info: 'info {
    #[doc(hidden)]
    pub const __ANCHOR_IX_PARAM_COUNT: usize = 0;
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_0<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_1<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_2<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_3<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_4<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_5<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_6<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_7<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_8<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_9<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_10<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_11<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_12<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_13<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_14<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_15<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_16<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_17<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_18<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_19<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_20<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_21<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_22<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_23<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_24<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_25<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_26<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_27<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_28<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_29<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_30<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_31<__T>(_arg: &__T) {}
}
#[automatically_derived]
impl<'info> anchor_lang::Accounts<'info, AdminConfigBumps> for
    AdminConfig<'info> where 'info: 'info {
    #[inline(never)]
    fn try_accounts(__program_id:
            &anchor_lang::solana_program::pubkey::Pubkey,
        __accounts:
            &mut &'info [anchor_lang::solana_program::account_info::AccountInfo<'info>],
        __ix_data: &[u8], __bumps: &mut AdminConfigBumps,
        __reallocs:
            &mut ::std::collections::BTreeSet<anchor_lang::solana_program::pubkey::Pubkey>)
        -> anchor_lang::Result<Self> {
        let admin: Signer =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("admin"))?;
        let config: anchor_lang::accounts::account::Account<Config> =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("config"))?;
        {
            let mut __mutable_accounts = ::std::collections::HashSet::new();
            if let Some(key) = Some(config.key()) {
                if !__mutable_accounts.insert(key) {
                    return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintDuplicateMutableAccount).with_account_name("config"));
                }
            }
        }
        let __pda_address =
            Pubkey::create_program_address(&[b"config", &[config.bump][..]],
                        &__program_id).map_err(|_|
                        anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("config"))?;
        if config.key() != __pda_address {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("config").with_pubkeys((config.key(),
                            __pda_address)));
        }
        if !AsRef::<AccountInfo>::as_ref(&config).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("config"));
        }
        {
            let my_key = config.admin;
            let target_key = admin.key();
            if my_key != target_key {
                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintHasOne).with_account_name("config").with_pubkeys((my_key,
                                target_key)));
            }
        }
        Ok(AdminConfig { admin, config })
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountInfos<'info> for AdminConfig<'info> where
    'info: 'info {
    fn to_account_infos(&self)
        ->
            Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
        let mut account_infos = ::alloc::vec::Vec::new();
        account_infos.extend(self.admin.to_account_infos());
        account_infos.extend(self.config.to_account_infos());
        account_infos
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountMetas for AdminConfig<'info> {
    fn to_account_metas(&self, is_signer: Option<bool>)
        -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
        let mut account_metas = ::alloc::vec::Vec::new();
        account_metas.extend(self.admin.to_account_metas(None));
        account_metas.extend(self.config.to_account_metas(None));
        account_metas
    }
}
#[automatically_derived]
impl<'info> anchor_lang::AccountsExit<'info> for AdminConfig<'info> where
    'info: 'info {
    fn exit(&self, program_id: &anchor_lang::solana_program::pubkey::Pubkey)
        -> anchor_lang::Result<()> {
        anchor_lang::AccountsExit::exit(&self.config,
                    program_id).map_err(|e| e.with_account_name("config"))?;
        Ok(())
    }
}
#[automatically_derived]
impl<'info> anchor_lang::DuplicateMutableAccountKeys for AdminConfig<'info>
    where 'info: 'info {
    fn duplicate_mutable_account_keys(&self)
        -> Vec<anchor_lang::solana_program::pubkey::Pubkey> {
        let mut keys = Vec::new();
        keys.push(self.config.key());
        keys
    }
}
#[automatically_derived]
impl<'info> AdminConfig<'info> where 'info: 'info {
    #[doc(hidden)]
    #[inline(always)]
    pub unsafe fn __shorten_invariant_lifetime<'__a,
        '__info: '__a>(value: &'__a mut AdminConfig<'__info>)
        -> &'__a mut AdminConfig<'__a> {
        unsafe { ::core::mem::transmute(value) }
    }
}
pub struct AdminConfigBumps {}
#[automatically_derived]
impl ::core::fmt::Debug for AdminConfigBumps {
    #[inline]
    fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
        ::core::fmt::Formatter::write_str(f, "AdminConfigBumps")
    }
}
#[automatically_derived]
#[doc(hidden)]
unsafe impl ::core::clone::TrivialClone for AdminConfigBumps { }
#[automatically_derived]
impl ::core::clone::Clone for AdminConfigBumps {
    #[inline]
    fn clone(&self) -> AdminConfigBumps { *self }
}
#[automatically_derived]
impl ::core::marker::Copy for AdminConfigBumps { }
impl Default for AdminConfigBumps {
    fn default() -> Self { AdminConfigBumps {} }
}
impl<'info> anchor_lang::Bumps for AdminConfig<'info> where 'info: 'info {
    type Bumps = AdminConfigBumps;
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a struct for a given"]
#[doc =
r" `#[derive(Accounts)]` implementation, where each field is a Pubkey,"]
#[doc = r" instead of an `AccountInfo`. This is useful for clients that want"]
#[doc = r" to generate a list of accounts, without explicitly knowing the"]
#[doc = r" order all the fields should be in."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" `accounts` module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __client_accounts_admin_config {
    use super::*;
    use anchor_lang::prelude::borsh;
    #[doc = " Generated client accounts for [`AdminConfig`]."]
    pub struct AdminConfig {
        pub admin: Pubkey,
        pub config: Pubkey,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for AdminConfig {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.admin,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.config,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for AdminConfig {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field2_finish(f,
                "AdminConfig", "admin", &self.admin, "config", &&self.config)
        }
    }
    #[automatically_derived]
    impl ::core::default::Default for AdminConfig {
        #[inline]
        fn default() -> AdminConfig {
            AdminConfig {
                admin: ::core::default::Default::default(),
                config: ::core::default::Default::default(),
            }
        }
    }
    #[automatically_derived]
    impl ::core::marker::Copy for AdminConfig { }
    #[automatically_derived]
    #[doc(hidden)]
    unsafe impl ::core::clone::TrivialClone for AdminConfig { }
    #[automatically_derived]
    impl ::core::clone::Clone for AdminConfig {
        #[inline]
        fn clone(&self) -> AdminConfig {
            let _: ::core::clone::AssertParamIsClone<Pubkey>;
            *self
        }
    }
    #[automatically_derived]
    impl anchor_lang::ToAccountMetas for AdminConfig {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(self.admin,
                    is_signer.unwrap_or(true)));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.config,
                    false));
            account_metas
        }
    }
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a CPI struct for a given"]
#[doc = r" `#[derive(Accounts)]` implementation, where each field is an"]
#[doc = r" AccountInfo."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" [`cpi::accounts`] module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __cpi_client_accounts_admin_config {
    use super::*;
    #[doc = " Generated CPI struct of the accounts for [`AdminConfig`]."]
    pub struct AdminConfig<'info> {
        pub admin: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub config: anchor_lang::solana_program::account_info::AccountInfo<'info>,
    }
    #[automatically_derived]
    impl<'info> ::core::fmt::Debug for AdminConfig<'info> {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field2_finish(f,
                "AdminConfig", "admin", &self.admin, "config", &&self.config)
        }
    }
    #[automatically_derived]
    impl<'info> ::core::clone::Clone for AdminConfig<'info> {
        #[inline]
        fn clone(&self) -> AdminConfig<'info> {
            AdminConfig {
                admin: ::core::clone::Clone::clone(&self.admin),
                config: ::core::clone::Clone::clone(&self.config),
            }
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountMetas for AdminConfig<'info> {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(anchor_lang::Key::key(&self.admin),
                    is_signer.unwrap_or(true)));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.config),
                    false));
            account_metas
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountInfos<'info> for AdminConfig<'info> {
        fn to_account_infos(&self)
            ->
                Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
            let mut account_infos = ::alloc::vec::Vec::new();
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.admin));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.config));
            account_infos
        }
    }
}
pub struct AcceptAdmin<'info> {
    pub pending_admin: Signer<'info>,
    #[account(mut, seeds = [b"config"], bump = config.bump)]
    pub config: Account<'info, Config>,
}
#[automatically_derived]
impl<'info> AcceptAdmin<'info> where 'info: 'info {
    #[doc(hidden)]
    pub const __ANCHOR_IX_PARAM_COUNT: usize = 0;
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_0<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_1<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_2<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_3<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_4<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_5<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_6<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_7<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_8<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_9<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_10<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_11<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_12<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_13<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_14<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_15<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_16<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_17<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_18<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_19<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_20<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_21<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_22<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_23<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_24<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_25<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_26<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_27<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_28<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_29<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_30<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_31<__T>(_arg: &__T) {}
}
#[automatically_derived]
impl<'info> anchor_lang::Accounts<'info, AcceptAdminBumps> for
    AcceptAdmin<'info> where 'info: 'info {
    #[inline(never)]
    fn try_accounts(__program_id:
            &anchor_lang::solana_program::pubkey::Pubkey,
        __accounts:
            &mut &'info [anchor_lang::solana_program::account_info::AccountInfo<'info>],
        __ix_data: &[u8], __bumps: &mut AcceptAdminBumps,
        __reallocs:
            &mut ::std::collections::BTreeSet<anchor_lang::solana_program::pubkey::Pubkey>)
        -> anchor_lang::Result<Self> {
        let pending_admin: Signer =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e|
                        e.with_account_name("pending_admin"))?;
        let config: anchor_lang::accounts::account::Account<Config> =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("config"))?;
        {
            let mut __mutable_accounts = ::std::collections::HashSet::new();
            if let Some(key) = Some(config.key()) {
                if !__mutable_accounts.insert(key) {
                    return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintDuplicateMutableAccount).with_account_name("config"));
                }
            }
        }
        let __pda_address =
            Pubkey::create_program_address(&[b"config", &[config.bump][..]],
                        &__program_id).map_err(|_|
                        anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("config"))?;
        if config.key() != __pda_address {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("config").with_pubkeys((config.key(),
                            __pda_address)));
        }
        if !AsRef::<AccountInfo>::as_ref(&config).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("config"));
        }
        Ok(AcceptAdmin { pending_admin, config })
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountInfos<'info> for AcceptAdmin<'info> where
    'info: 'info {
    fn to_account_infos(&self)
        ->
            Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
        let mut account_infos = ::alloc::vec::Vec::new();
        account_infos.extend(self.pending_admin.to_account_infos());
        account_infos.extend(self.config.to_account_infos());
        account_infos
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountMetas for AcceptAdmin<'info> {
    fn to_account_metas(&self, is_signer: Option<bool>)
        -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
        let mut account_metas = ::alloc::vec::Vec::new();
        account_metas.extend(self.pending_admin.to_account_metas(None));
        account_metas.extend(self.config.to_account_metas(None));
        account_metas
    }
}
#[automatically_derived]
impl<'info> anchor_lang::AccountsExit<'info> for AcceptAdmin<'info> where
    'info: 'info {
    fn exit(&self, program_id: &anchor_lang::solana_program::pubkey::Pubkey)
        -> anchor_lang::Result<()> {
        anchor_lang::AccountsExit::exit(&self.config,
                    program_id).map_err(|e| e.with_account_name("config"))?;
        Ok(())
    }
}
#[automatically_derived]
impl<'info> anchor_lang::DuplicateMutableAccountKeys for AcceptAdmin<'info>
    where 'info: 'info {
    fn duplicate_mutable_account_keys(&self)
        -> Vec<anchor_lang::solana_program::pubkey::Pubkey> {
        let mut keys = Vec::new();
        keys.push(self.config.key());
        keys
    }
}
#[automatically_derived]
impl<'info> AcceptAdmin<'info> where 'info: 'info {
    #[doc(hidden)]
    #[inline(always)]
    pub unsafe fn __shorten_invariant_lifetime<'__a,
        '__info: '__a>(value: &'__a mut AcceptAdmin<'__info>)
        -> &'__a mut AcceptAdmin<'__a> {
        unsafe { ::core::mem::transmute(value) }
    }
}
pub struct AcceptAdminBumps {}
#[automatically_derived]
impl ::core::fmt::Debug for AcceptAdminBumps {
    #[inline]
    fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
        ::core::fmt::Formatter::write_str(f, "AcceptAdminBumps")
    }
}
#[automatically_derived]
#[doc(hidden)]
unsafe impl ::core::clone::TrivialClone for AcceptAdminBumps { }
#[automatically_derived]
impl ::core::clone::Clone for AcceptAdminBumps {
    #[inline]
    fn clone(&self) -> AcceptAdminBumps { *self }
}
#[automatically_derived]
impl ::core::marker::Copy for AcceptAdminBumps { }
impl Default for AcceptAdminBumps {
    fn default() -> Self { AcceptAdminBumps {} }
}
impl<'info> anchor_lang::Bumps for AcceptAdmin<'info> where 'info: 'info {
    type Bumps = AcceptAdminBumps;
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a struct for a given"]
#[doc =
r" `#[derive(Accounts)]` implementation, where each field is a Pubkey,"]
#[doc = r" instead of an `AccountInfo`. This is useful for clients that want"]
#[doc = r" to generate a list of accounts, without explicitly knowing the"]
#[doc = r" order all the fields should be in."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" `accounts` module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __client_accounts_accept_admin {
    use super::*;
    use anchor_lang::prelude::borsh;
    #[doc = " Generated client accounts for [`AcceptAdmin`]."]
    pub struct AcceptAdmin {
        pub pending_admin: Pubkey,
        pub config: Pubkey,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for AcceptAdmin {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.pending_admin,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.config,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for AcceptAdmin {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field2_finish(f,
                "AcceptAdmin", "pending_admin", &self.pending_admin, "config",
                &&self.config)
        }
    }
    #[automatically_derived]
    impl ::core::default::Default for AcceptAdmin {
        #[inline]
        fn default() -> AcceptAdmin {
            AcceptAdmin {
                pending_admin: ::core::default::Default::default(),
                config: ::core::default::Default::default(),
            }
        }
    }
    #[automatically_derived]
    impl ::core::marker::Copy for AcceptAdmin { }
    #[automatically_derived]
    #[doc(hidden)]
    unsafe impl ::core::clone::TrivialClone for AcceptAdmin { }
    #[automatically_derived]
    impl ::core::clone::Clone for AcceptAdmin {
        #[inline]
        fn clone(&self) -> AcceptAdmin {
            let _: ::core::clone::AssertParamIsClone<Pubkey>;
            *self
        }
    }
    #[automatically_derived]
    impl anchor_lang::ToAccountMetas for AcceptAdmin {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(self.pending_admin,
                    is_signer.unwrap_or(true)));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.config,
                    false));
            account_metas
        }
    }
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a CPI struct for a given"]
#[doc = r" `#[derive(Accounts)]` implementation, where each field is an"]
#[doc = r" AccountInfo."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" [`cpi::accounts`] module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __cpi_client_accounts_accept_admin {
    use super::*;
    #[doc = " Generated CPI struct of the accounts for [`AcceptAdmin`]."]
    pub struct AcceptAdmin<'info> {
        pub pending_admin: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub config: anchor_lang::solana_program::account_info::AccountInfo<'info>,
    }
    #[automatically_derived]
    impl<'info> ::core::fmt::Debug for AcceptAdmin<'info> {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field2_finish(f,
                "AcceptAdmin", "pending_admin", &self.pending_admin, "config",
                &&self.config)
        }
    }
    #[automatically_derived]
    impl<'info> ::core::clone::Clone for AcceptAdmin<'info> {
        #[inline]
        fn clone(&self) -> AcceptAdmin<'info> {
            AcceptAdmin {
                pending_admin: ::core::clone::Clone::clone(&self.pending_admin),
                config: ::core::clone::Clone::clone(&self.config),
            }
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountMetas for AcceptAdmin<'info> {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(anchor_lang::Key::key(&self.pending_admin),
                    is_signer.unwrap_or(true)));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.config),
                    false));
            account_metas
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountInfos<'info> for AcceptAdmin<'info> {
        fn to_account_infos(&self)
            ->
                Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
            let mut account_infos = ::alloc::vec::Vec::new();
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.pending_admin));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.config));
            account_infos
        }
    }
}
#[instruction(booking: [u8; 32])]
pub struct Open<'info> {
    #[account(seeds = [b"config"], bump = config.bump)]
    pub config: Account<'info, Config>,
    #[account(mut)]
    pub buyer: Signer<'info>,
    /// CHECK: destination wallet is stored and constrained during settlement.
    pub provider: UncheckedAccount<'info>,
    #[account(init, payer = buyer, space = 8 + Escrow::INIT_SPACE, seeds =
    [b"escrow", booking.as_ref()], bump)]
    pub escrow: Account<'info, Escrow>,
    pub system_program: Program<'info, System>,
}
#[automatically_derived]
impl<'info> Open<'info> where 'info: 'info {
    #[doc(hidden)]
    pub const __ANCHOR_IX_PARAM_COUNT: usize = 1usize;
    #[doc(hidden)]
    #[inline(always)]
    pub fn __anchor_validate_ix_arg_type_0(_arg: &[u8; 32]) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_1<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_2<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_3<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_4<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_5<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_6<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_7<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_8<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_9<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_10<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_11<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_12<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_13<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_14<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_15<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_16<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_17<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_18<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_19<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_20<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_21<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_22<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_23<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_24<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_25<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_26<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_27<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_28<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_29<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_30<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_31<__T>(_arg: &__T) {}
}
#[automatically_derived]
impl<'info> anchor_lang::Accounts<'info, OpenBumps> for Open<'info> where
    'info: 'info {
    #[inline(never)]
    fn try_accounts(__program_id:
            &anchor_lang::solana_program::pubkey::Pubkey,
        __accounts:
            &mut &'info [anchor_lang::solana_program::account_info::AccountInfo<'info>],
        __ix_data: &[u8], __bumps: &mut OpenBumps,
        __reallocs:
            &mut ::std::collections::BTreeSet<anchor_lang::solana_program::pubkey::Pubkey>)
        -> anchor_lang::Result<Self> {
        let mut __ix_data = __ix_data;
        let booking: [u8; 32] =
            <[u8; 32] as
                            anchor_lang::AnchorDeserialize>::deserialize(&mut __ix_data).map_err(|_|
                        anchor_lang::error::ErrorCode::InstructionDidNotDeserialize)?;
        let config: anchor_lang::accounts::account::Account<Config> =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("config"))?;
        let buyer: Signer =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("buyer"))?;
        let provider: UncheckedAccount =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("provider"))?;
        if __accounts.is_empty() {
            return Err(anchor_lang::error::ErrorCode::AccountNotEnoughKeys.into());
        }
        let escrow = &__accounts[0];
        *__accounts = &__accounts[1..];
        let system_program:
                anchor_lang::accounts::program::Program<'info, System> =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e|
                        e.with_account_name("system_program"))?;
        let __anchor_rent = Rent::get()?;
        let (__pda_address, __bump) =
            Pubkey::find_program_address(&[b"escrow", booking.as_ref()],
                __program_id);
        __bumps.escrow = __bump;
        if escrow.key() != __pda_address {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("escrow").with_pubkeys((escrow.key(),
                            __pda_address)));
        }
        let escrow =
            ({

                            #[inline(never)]
                            ||
                                {
                                    let actual_field = AsRef::<AccountInfo>::as_ref(&escrow);
                                    let actual_owner = actual_field.owner;
                                    let space = 8 + Escrow::INIT_SPACE;
                                    let pa: anchor_lang::accounts::account::Account<Escrow> =
                                        if !false ||
                                                actual_owner ==
                                                    &anchor_lang::solana_program::system_program::ID {
                                            let __current_lamports = escrow.lamports();
                                            if __current_lamports == 0 {
                                                let space = space;
                                                let lamports = __anchor_rent.minimum_balance(space);
                                                let cpi_accounts =
                                                    anchor_lang::system_program::CreateAccount {
                                                        from: buyer.to_account_info(),
                                                        to: escrow.to_account_info(),
                                                    };
                                                let cpi_context =
                                                    anchor_lang::context::CpiContext::new(system_program.key(),
                                                        cpi_accounts);
                                                anchor_lang::system_program::create_account(cpi_context.with_signer(&[&[b"escrow",
                                                                                        booking.as_ref(), &[__bump][..]][..]]), lamports,
                                                        space as u64, __program_id)?;
                                            } else {
                                                if buyer.key() == escrow.key() {
                                                    return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                                                                        error_name: anchor_lang::error::ErrorCode::TryingToInitPayerAsProgramAccount.name(),
                                                                        error_code_number: anchor_lang::error::ErrorCode::TryingToInitPayerAsProgramAccount.into(),
                                                                        error_msg: anchor_lang::error::ErrorCode::TryingToInitPayerAsProgramAccount.to_string(),
                                                                        error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                                                                    filename: "programs/gpu_escrow/src/lib.rs",
                                                                                    line: 195u32,
                                                                                })),
                                                                        compared_values: None,
                                                                    }).with_pubkeys((buyer.key(), escrow.key())));
                                                };
                                                let required_lamports =
                                                    __anchor_rent.minimum_balance(space).max(1).saturating_sub(__current_lamports);
                                                let cpi_accounts =
                                                    anchor_lang::system_program::CreateAccountAllowPrefund {
                                                        from: buyer.to_account_info(),
                                                        to: escrow.to_account_info(),
                                                    };
                                                let cpi_context =
                                                    anchor_lang::context::CpiContext::new(system_program.key(),
                                                        cpi_accounts);
                                                anchor_lang::system_program::create_account_allow_prefund(cpi_context.with_signer(&[&[b"escrow",
                                                                                        booking.as_ref(), &[__bump][..]][..]]), required_lamports,
                                                        space as u64, __program_id)?;
                                            }
                                            match anchor_lang::accounts::account::Account::try_from_unchecked(&escrow)
                                                {
                                                Ok(val) => val,
                                                Err(e) => return Err(e.with_account_name("escrow")),
                                            }
                                        } else {
                                            match anchor_lang::accounts::account::Account::try_from(&escrow)
                                                {
                                                Ok(val) => val,
                                                Err(e) => return Err(e.with_account_name("escrow")),
                                            }
                                        };
                                    if false {
                                        if space != actual_field.data_len() {
                                            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSpace).with_account_name("escrow").with_values((space,
                                                            actual_field.data_len())));
                                        }
                                        if actual_owner != __program_id {
                                            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintOwner).with_account_name("escrow").with_pubkeys((*actual_owner,
                                                            *__program_id)));
                                        }
                                        {
                                            let required_lamports =
                                                __anchor_rent.minimum_balance(space);
                                            if anchor_lang::Lamports::get_lamports(actual_field) <
                                                    required_lamports {
                                                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintRentExempt).with_account_name("escrow"));
                                            }
                                        }
                                    }
                                    Ok(pa)
                                }
                        })()?;
        if !AsRef::<AccountInfo>::as_ref(&escrow).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("escrow"));
        }
        if !__anchor_rent.is_exempt(escrow.to_account_info().lamports(),
                    escrow.to_account_info().try_data_len()?) {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintRentExempt).with_account_name("escrow"));
        }
        let __pda_address =
            Pubkey::create_program_address(&[b"config", &[config.bump][..]],
                        &__program_id).map_err(|_|
                        anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("config"))?;
        if config.key() != __pda_address {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("config").with_pubkeys((config.key(),
                            __pda_address)));
        }
        if !AsRef::<AccountInfo>::as_ref(&buyer).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("buyer"));
        }
        Ok(Open { config, buyer, provider, escrow, system_program })
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountInfos<'info> for Open<'info> where
    'info: 'info {
    fn to_account_infos(&self)
        ->
            Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
        let mut account_infos = ::alloc::vec::Vec::new();
        account_infos.extend(self.config.to_account_infos());
        account_infos.extend(self.buyer.to_account_infos());
        account_infos.extend(self.provider.to_account_infos());
        account_infos.extend(self.escrow.to_account_infos());
        account_infos.extend(self.system_program.to_account_infos());
        account_infos
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountMetas for Open<'info> {
    fn to_account_metas(&self, is_signer: Option<bool>)
        -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
        let mut account_metas = ::alloc::vec::Vec::new();
        account_metas.extend(self.config.to_account_metas(None));
        account_metas.extend(self.buyer.to_account_metas(None));
        account_metas.extend(self.provider.to_account_metas(None));
        account_metas.extend(self.escrow.to_account_metas(None));
        account_metas.extend(self.system_program.to_account_metas(None));
        account_metas
    }
}
#[automatically_derived]
impl<'info> anchor_lang::AccountsExit<'info> for Open<'info> where
    'info: 'info {
    fn exit(&self, program_id: &anchor_lang::solana_program::pubkey::Pubkey)
        -> anchor_lang::Result<()> {
        anchor_lang::AccountsExit::exit(&self.buyer,
                    program_id).map_err(|e| e.with_account_name("buyer"))?;
        anchor_lang::AccountsExit::exit(&self.escrow,
                    program_id).map_err(|e| e.with_account_name("escrow"))?;
        Ok(())
    }
}
#[automatically_derived]
impl<'info> anchor_lang::DuplicateMutableAccountKeys for Open<'info> where
    'info: 'info {
    fn duplicate_mutable_account_keys(&self)
        -> Vec<anchor_lang::solana_program::pubkey::Pubkey> {
        let mut keys = Vec::new();
        keys
    }
}
#[automatically_derived]
impl<'info> Open<'info> where 'info: 'info {
    #[doc(hidden)]
    #[inline(always)]
    pub unsafe fn __shorten_invariant_lifetime<'__a,
        '__info: '__a>(value: &'__a mut Open<'__info>)
        -> &'__a mut Open<'__a> {
        unsafe { ::core::mem::transmute(value) }
    }
}
pub struct OpenBumps {
    pub escrow: u8,
}
#[automatically_derived]
impl ::core::fmt::Debug for OpenBumps {
    #[inline]
    fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
        ::core::fmt::Formatter::debug_struct_field1_finish(f, "OpenBumps",
            "escrow", &&self.escrow)
    }
}
#[automatically_derived]
#[doc(hidden)]
unsafe impl ::core::clone::TrivialClone for OpenBumps { }
#[automatically_derived]
impl ::core::clone::Clone for OpenBumps {
    #[inline]
    fn clone(&self) -> OpenBumps {
        let _: ::core::clone::AssertParamIsClone<u8>;
        *self
    }
}
#[automatically_derived]
impl ::core::marker::Copy for OpenBumps { }
impl Default for OpenBumps {
    fn default() -> Self { OpenBumps { escrow: u8::MAX } }
}
impl<'info> anchor_lang::Bumps for Open<'info> where 'info: 'info {
    type Bumps = OpenBumps;
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a struct for a given"]
#[doc =
r" `#[derive(Accounts)]` implementation, where each field is a Pubkey,"]
#[doc = r" instead of an `AccountInfo`. This is useful for clients that want"]
#[doc = r" to generate a list of accounts, without explicitly knowing the"]
#[doc = r" order all the fields should be in."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" `accounts` module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __client_accounts_open {
    use super::*;
    use anchor_lang::prelude::borsh;
    #[doc = " Generated client accounts for [`Open`]."]
    pub struct Open {
        pub config: Pubkey,
        pub buyer: Pubkey,
        pub provider: Pubkey,
        pub escrow: Pubkey,
        pub system_program: Pubkey,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for Open {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.config,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.buyer,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.provider,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.escrow,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.system_program,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for Open {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field5_finish(f, "Open",
                "config", &self.config, "buyer", &self.buyer, "provider",
                &self.provider, "escrow", &self.escrow, "system_program",
                &&self.system_program)
        }
    }
    #[automatically_derived]
    impl ::core::default::Default for Open {
        #[inline]
        fn default() -> Open {
            Open {
                config: ::core::default::Default::default(),
                buyer: ::core::default::Default::default(),
                provider: ::core::default::Default::default(),
                escrow: ::core::default::Default::default(),
                system_program: ::core::default::Default::default(),
            }
        }
    }
    #[automatically_derived]
    impl ::core::marker::Copy for Open { }
    #[automatically_derived]
    #[doc(hidden)]
    unsafe impl ::core::clone::TrivialClone for Open { }
    #[automatically_derived]
    impl ::core::clone::Clone for Open {
        #[inline]
        fn clone(&self) -> Open {
            let _: ::core::clone::AssertParamIsClone<Pubkey>;
            *self
        }
    }
    #[automatically_derived]
    impl anchor_lang::ToAccountMetas for Open {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(self.config,
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.buyer,
                    is_signer.unwrap_or(true)));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(self.provider,
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.escrow,
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(self.system_program,
                    false));
            account_metas
        }
    }
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a CPI struct for a given"]
#[doc = r" `#[derive(Accounts)]` implementation, where each field is an"]
#[doc = r" AccountInfo."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" [`cpi::accounts`] module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __cpi_client_accounts_open {
    use super::*;
    #[doc = " Generated CPI struct of the accounts for [`Open`]."]
    pub struct Open<'info> {
        pub config: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub buyer: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub provider: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub escrow: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub system_program: anchor_lang::solana_program::account_info::AccountInfo<'info>,
    }
    #[automatically_derived]
    impl<'info> ::core::fmt::Debug for Open<'info> {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field5_finish(f, "Open",
                "config", &self.config, "buyer", &self.buyer, "provider",
                &self.provider, "escrow", &self.escrow, "system_program",
                &&self.system_program)
        }
    }
    #[automatically_derived]
    impl<'info> ::core::clone::Clone for Open<'info> {
        #[inline]
        fn clone(&self) -> Open<'info> {
            Open {
                config: ::core::clone::Clone::clone(&self.config),
                buyer: ::core::clone::Clone::clone(&self.buyer),
                provider: ::core::clone::Clone::clone(&self.provider),
                escrow: ::core::clone::Clone::clone(&self.escrow),
                system_program: ::core::clone::Clone::clone(&self.system_program),
            }
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountMetas for Open<'info> {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(anchor_lang::Key::key(&self.config),
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.buyer),
                    is_signer.unwrap_or(true)));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(anchor_lang::Key::key(&self.provider),
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.escrow),
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(anchor_lang::Key::key(&self.system_program),
                    false));
            account_metas
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountInfos<'info> for Open<'info> {
        fn to_account_infos(&self)
            ->
                Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
            let mut account_infos = ::alloc::vec::Vec::new();
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.config));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.buyer));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.provider));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.escrow));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.system_program));
            account_infos
        }
    }
}
pub struct ProposeSettlement<'info> {
    #[account(seeds = [b"config"], bump = config.bump, has_one = oracle)]
    pub config: Account<'info, Config>,
    pub oracle: Signer<'info>,
    #[account(mut, seeds = [b"escrow", escrow.booking.as_ref()], bump =
    escrow.bump)]
    pub escrow: Account<'info, Escrow>,
}
#[automatically_derived]
impl<'info> ProposeSettlement<'info> where 'info: 'info {
    #[doc(hidden)]
    pub const __ANCHOR_IX_PARAM_COUNT: usize = 0;
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_0<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_1<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_2<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_3<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_4<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_5<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_6<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_7<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_8<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_9<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_10<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_11<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_12<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_13<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_14<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_15<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_16<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_17<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_18<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_19<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_20<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_21<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_22<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_23<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_24<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_25<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_26<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_27<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_28<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_29<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_30<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_31<__T>(_arg: &__T) {}
}
#[automatically_derived]
impl<'info> anchor_lang::Accounts<'info, ProposeSettlementBumps> for
    ProposeSettlement<'info> where 'info: 'info {
    #[inline(never)]
    fn try_accounts(__program_id:
            &anchor_lang::solana_program::pubkey::Pubkey,
        __accounts:
            &mut &'info [anchor_lang::solana_program::account_info::AccountInfo<'info>],
        __ix_data: &[u8], __bumps: &mut ProposeSettlementBumps,
        __reallocs:
            &mut ::std::collections::BTreeSet<anchor_lang::solana_program::pubkey::Pubkey>)
        -> anchor_lang::Result<Self> {
        let config: anchor_lang::accounts::account::Account<Config> =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("config"))?;
        let oracle: Signer =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("oracle"))?;
        let escrow: anchor_lang::accounts::account::Account<Escrow> =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("escrow"))?;
        {
            let mut __mutable_accounts = ::std::collections::HashSet::new();
            if let Some(key) = Some(escrow.key()) {
                if !__mutable_accounts.insert(key) {
                    return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintDuplicateMutableAccount).with_account_name("escrow"));
                }
            }
        }
        let __pda_address =
            Pubkey::create_program_address(&[b"config", &[config.bump][..]],
                        &__program_id).map_err(|_|
                        anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("config"))?;
        if config.key() != __pda_address {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("config").with_pubkeys((config.key(),
                            __pda_address)));
        }
        {
            let my_key = config.oracle;
            let target_key = oracle.key();
            if my_key != target_key {
                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintHasOne).with_account_name("config").with_pubkeys((my_key,
                                target_key)));
            }
        }
        let __pda_address =
            Pubkey::create_program_address(&[b"escrow",
                                    escrow.booking.as_ref(), &[escrow.bump][..]],
                        &__program_id).map_err(|_|
                        anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("escrow"))?;
        if escrow.key() != __pda_address {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("escrow").with_pubkeys((escrow.key(),
                            __pda_address)));
        }
        if !AsRef::<AccountInfo>::as_ref(&escrow).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("escrow"));
        }
        Ok(ProposeSettlement { config, oracle, escrow })
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountInfos<'info> for ProposeSettlement<'info>
    where 'info: 'info {
    fn to_account_infos(&self)
        ->
            Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
        let mut account_infos = ::alloc::vec::Vec::new();
        account_infos.extend(self.config.to_account_infos());
        account_infos.extend(self.oracle.to_account_infos());
        account_infos.extend(self.escrow.to_account_infos());
        account_infos
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountMetas for ProposeSettlement<'info> {
    fn to_account_metas(&self, is_signer: Option<bool>)
        -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
        let mut account_metas = ::alloc::vec::Vec::new();
        account_metas.extend(self.config.to_account_metas(None));
        account_metas.extend(self.oracle.to_account_metas(None));
        account_metas.extend(self.escrow.to_account_metas(None));
        account_metas
    }
}
#[automatically_derived]
impl<'info> anchor_lang::AccountsExit<'info> for ProposeSettlement<'info>
    where 'info: 'info {
    fn exit(&self, program_id: &anchor_lang::solana_program::pubkey::Pubkey)
        -> anchor_lang::Result<()> {
        anchor_lang::AccountsExit::exit(&self.escrow,
                    program_id).map_err(|e| e.with_account_name("escrow"))?;
        Ok(())
    }
}
#[automatically_derived]
impl<'info> anchor_lang::DuplicateMutableAccountKeys for
    ProposeSettlement<'info> where 'info: 'info {
    fn duplicate_mutable_account_keys(&self)
        -> Vec<anchor_lang::solana_program::pubkey::Pubkey> {
        let mut keys = Vec::new();
        keys.push(self.escrow.key());
        keys
    }
}
#[automatically_derived]
impl<'info> ProposeSettlement<'info> where 'info: 'info {
    #[doc(hidden)]
    #[inline(always)]
    pub unsafe fn __shorten_invariant_lifetime<'__a,
        '__info: '__a>(value: &'__a mut ProposeSettlement<'__info>)
        -> &'__a mut ProposeSettlement<'__a> {
        unsafe { ::core::mem::transmute(value) }
    }
}
pub struct ProposeSettlementBumps {}
#[automatically_derived]
impl ::core::fmt::Debug for ProposeSettlementBumps {
    #[inline]
    fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
        ::core::fmt::Formatter::write_str(f, "ProposeSettlementBumps")
    }
}
#[automatically_derived]
#[doc(hidden)]
unsafe impl ::core::clone::TrivialClone for ProposeSettlementBumps { }
#[automatically_derived]
impl ::core::clone::Clone for ProposeSettlementBumps {
    #[inline]
    fn clone(&self) -> ProposeSettlementBumps { *self }
}
#[automatically_derived]
impl ::core::marker::Copy for ProposeSettlementBumps { }
impl Default for ProposeSettlementBumps {
    fn default() -> Self { ProposeSettlementBumps {} }
}
impl<'info> anchor_lang::Bumps for ProposeSettlement<'info> where 'info: 'info
    {
    type Bumps = ProposeSettlementBumps;
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a struct for a given"]
#[doc =
r" `#[derive(Accounts)]` implementation, where each field is a Pubkey,"]
#[doc = r" instead of an `AccountInfo`. This is useful for clients that want"]
#[doc = r" to generate a list of accounts, without explicitly knowing the"]
#[doc = r" order all the fields should be in."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" `accounts` module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __client_accounts_propose_settlement {
    use super::*;
    use anchor_lang::prelude::borsh;
    #[doc = " Generated client accounts for [`ProposeSettlement`]."]
    pub struct ProposeSettlement {
        pub config: Pubkey,
        pub oracle: Pubkey,
        pub escrow: Pubkey,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for
        ProposeSettlement {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.config,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.oracle,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.escrow,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for ProposeSettlement {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field3_finish(f,
                "ProposeSettlement", "config", &self.config, "oracle",
                &self.oracle, "escrow", &&self.escrow)
        }
    }
    #[automatically_derived]
    impl ::core::default::Default for ProposeSettlement {
        #[inline]
        fn default() -> ProposeSettlement {
            ProposeSettlement {
                config: ::core::default::Default::default(),
                oracle: ::core::default::Default::default(),
                escrow: ::core::default::Default::default(),
            }
        }
    }
    #[automatically_derived]
    impl ::core::marker::Copy for ProposeSettlement { }
    #[automatically_derived]
    #[doc(hidden)]
    unsafe impl ::core::clone::TrivialClone for ProposeSettlement { }
    #[automatically_derived]
    impl ::core::clone::Clone for ProposeSettlement {
        #[inline]
        fn clone(&self) -> ProposeSettlement {
            let _: ::core::clone::AssertParamIsClone<Pubkey>;
            *self
        }
    }
    #[automatically_derived]
    impl anchor_lang::ToAccountMetas for ProposeSettlement {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(self.config,
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(self.oracle,
                    is_signer.unwrap_or(true)));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.escrow,
                    false));
            account_metas
        }
    }
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a CPI struct for a given"]
#[doc = r" `#[derive(Accounts)]` implementation, where each field is an"]
#[doc = r" AccountInfo."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" [`cpi::accounts`] module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __cpi_client_accounts_propose_settlement {
    use super::*;
    #[doc =
    " Generated CPI struct of the accounts for [`ProposeSettlement`]."]
    pub struct ProposeSettlement<'info> {
        pub config: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub oracle: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub escrow: anchor_lang::solana_program::account_info::AccountInfo<'info>,
    }
    #[automatically_derived]
    impl<'info> ::core::fmt::Debug for ProposeSettlement<'info> {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field3_finish(f,
                "ProposeSettlement", "config", &self.config, "oracle",
                &self.oracle, "escrow", &&self.escrow)
        }
    }
    #[automatically_derived]
    impl<'info> ::core::clone::Clone for ProposeSettlement<'info> {
        #[inline]
        fn clone(&self) -> ProposeSettlement<'info> {
            ProposeSettlement {
                config: ::core::clone::Clone::clone(&self.config),
                oracle: ::core::clone::Clone::clone(&self.oracle),
                escrow: ::core::clone::Clone::clone(&self.escrow),
            }
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountMetas for ProposeSettlement<'info> {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(anchor_lang::Key::key(&self.config),
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(anchor_lang::Key::key(&self.oracle),
                    is_signer.unwrap_or(true)));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.escrow),
                    false));
            account_metas
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountInfos<'info> for
        ProposeSettlement<'info> {
        fn to_account_infos(&self)
            ->
                Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
            let mut account_infos = ::alloc::vec::Vec::new();
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.config));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.oracle));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.escrow));
            account_infos
        }
    }
}
pub struct Dispute<'info> {
    pub buyer: Signer<'info>,
    #[account(mut, seeds = [b"escrow", escrow.booking.as_ref()], bump =
    escrow.bump, has_one = buyer)]
    pub escrow: Account<'info, Escrow>,
}
#[automatically_derived]
impl<'info> Dispute<'info> where 'info: 'info {
    #[doc(hidden)]
    pub const __ANCHOR_IX_PARAM_COUNT: usize = 0;
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_0<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_1<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_2<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_3<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_4<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_5<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_6<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_7<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_8<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_9<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_10<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_11<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_12<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_13<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_14<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_15<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_16<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_17<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_18<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_19<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_20<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_21<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_22<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_23<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_24<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_25<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_26<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_27<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_28<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_29<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_30<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_31<__T>(_arg: &__T) {}
}
#[automatically_derived]
impl<'info> anchor_lang::Accounts<'info, DisputeBumps> for Dispute<'info>
    where 'info: 'info {
    #[inline(never)]
    fn try_accounts(__program_id:
            &anchor_lang::solana_program::pubkey::Pubkey,
        __accounts:
            &mut &'info [anchor_lang::solana_program::account_info::AccountInfo<'info>],
        __ix_data: &[u8], __bumps: &mut DisputeBumps,
        __reallocs:
            &mut ::std::collections::BTreeSet<anchor_lang::solana_program::pubkey::Pubkey>)
        -> anchor_lang::Result<Self> {
        let buyer: Signer =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("buyer"))?;
        let escrow: anchor_lang::accounts::account::Account<Escrow> =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("escrow"))?;
        {
            let mut __mutable_accounts = ::std::collections::HashSet::new();
            if let Some(key) = Some(escrow.key()) {
                if !__mutable_accounts.insert(key) {
                    return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintDuplicateMutableAccount).with_account_name("escrow"));
                }
            }
        }
        let __pda_address =
            Pubkey::create_program_address(&[b"escrow",
                                    escrow.booking.as_ref(), &[escrow.bump][..]],
                        &__program_id).map_err(|_|
                        anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("escrow"))?;
        if escrow.key() != __pda_address {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("escrow").with_pubkeys((escrow.key(),
                            __pda_address)));
        }
        if !AsRef::<AccountInfo>::as_ref(&escrow).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("escrow"));
        }
        {
            let my_key = escrow.buyer;
            let target_key = buyer.key();
            if my_key != target_key {
                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintHasOne).with_account_name("escrow").with_pubkeys((my_key,
                                target_key)));
            }
        }
        Ok(Dispute { buyer, escrow })
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountInfos<'info> for Dispute<'info> where
    'info: 'info {
    fn to_account_infos(&self)
        ->
            Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
        let mut account_infos = ::alloc::vec::Vec::new();
        account_infos.extend(self.buyer.to_account_infos());
        account_infos.extend(self.escrow.to_account_infos());
        account_infos
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountMetas for Dispute<'info> {
    fn to_account_metas(&self, is_signer: Option<bool>)
        -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
        let mut account_metas = ::alloc::vec::Vec::new();
        account_metas.extend(self.buyer.to_account_metas(None));
        account_metas.extend(self.escrow.to_account_metas(None));
        account_metas
    }
}
#[automatically_derived]
impl<'info> anchor_lang::AccountsExit<'info> for Dispute<'info> where
    'info: 'info {
    fn exit(&self, program_id: &anchor_lang::solana_program::pubkey::Pubkey)
        -> anchor_lang::Result<()> {
        anchor_lang::AccountsExit::exit(&self.escrow,
                    program_id).map_err(|e| e.with_account_name("escrow"))?;
        Ok(())
    }
}
#[automatically_derived]
impl<'info> anchor_lang::DuplicateMutableAccountKeys for Dispute<'info> where
    'info: 'info {
    fn duplicate_mutable_account_keys(&self)
        -> Vec<anchor_lang::solana_program::pubkey::Pubkey> {
        let mut keys = Vec::new();
        keys.push(self.escrow.key());
        keys
    }
}
#[automatically_derived]
impl<'info> Dispute<'info> where 'info: 'info {
    #[doc(hidden)]
    #[inline(always)]
    pub unsafe fn __shorten_invariant_lifetime<'__a,
        '__info: '__a>(value: &'__a mut Dispute<'__info>)
        -> &'__a mut Dispute<'__a> {
        unsafe { ::core::mem::transmute(value) }
    }
}
pub struct DisputeBumps {}
#[automatically_derived]
impl ::core::fmt::Debug for DisputeBumps {
    #[inline]
    fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
        ::core::fmt::Formatter::write_str(f, "DisputeBumps")
    }
}
#[automatically_derived]
#[doc(hidden)]
unsafe impl ::core::clone::TrivialClone for DisputeBumps { }
#[automatically_derived]
impl ::core::clone::Clone for DisputeBumps {
    #[inline]
    fn clone(&self) -> DisputeBumps { *self }
}
#[automatically_derived]
impl ::core::marker::Copy for DisputeBumps { }
impl Default for DisputeBumps {
    fn default() -> Self { DisputeBumps {} }
}
impl<'info> anchor_lang::Bumps for Dispute<'info> where 'info: 'info {
    type Bumps = DisputeBumps;
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a struct for a given"]
#[doc =
r" `#[derive(Accounts)]` implementation, where each field is a Pubkey,"]
#[doc = r" instead of an `AccountInfo`. This is useful for clients that want"]
#[doc = r" to generate a list of accounts, without explicitly knowing the"]
#[doc = r" order all the fields should be in."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" `accounts` module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __client_accounts_dispute {
    use super::*;
    use anchor_lang::prelude::borsh;
    #[doc = " Generated client accounts for [`Dispute`]."]
    pub struct Dispute {
        pub buyer: Pubkey,
        pub escrow: Pubkey,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for Dispute {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.buyer,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.escrow,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for Dispute {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field2_finish(f, "Dispute",
                "buyer", &self.buyer, "escrow", &&self.escrow)
        }
    }
    #[automatically_derived]
    impl ::core::default::Default for Dispute {
        #[inline]
        fn default() -> Dispute {
            Dispute {
                buyer: ::core::default::Default::default(),
                escrow: ::core::default::Default::default(),
            }
        }
    }
    #[automatically_derived]
    impl ::core::marker::Copy for Dispute { }
    #[automatically_derived]
    #[doc(hidden)]
    unsafe impl ::core::clone::TrivialClone for Dispute { }
    #[automatically_derived]
    impl ::core::clone::Clone for Dispute {
        #[inline]
        fn clone(&self) -> Dispute {
            let _: ::core::clone::AssertParamIsClone<Pubkey>;
            *self
        }
    }
    #[automatically_derived]
    impl anchor_lang::ToAccountMetas for Dispute {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(self.buyer,
                    is_signer.unwrap_or(true)));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.escrow,
                    false));
            account_metas
        }
    }
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a CPI struct for a given"]
#[doc = r" `#[derive(Accounts)]` implementation, where each field is an"]
#[doc = r" AccountInfo."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" [`cpi::accounts`] module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __cpi_client_accounts_dispute {
    use super::*;
    #[doc = " Generated CPI struct of the accounts for [`Dispute`]."]
    pub struct Dispute<'info> {
        pub buyer: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub escrow: anchor_lang::solana_program::account_info::AccountInfo<'info>,
    }
    #[automatically_derived]
    impl<'info> ::core::fmt::Debug for Dispute<'info> {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field2_finish(f, "Dispute",
                "buyer", &self.buyer, "escrow", &&self.escrow)
        }
    }
    #[automatically_derived]
    impl<'info> ::core::clone::Clone for Dispute<'info> {
        #[inline]
        fn clone(&self) -> Dispute<'info> {
            Dispute {
                buyer: ::core::clone::Clone::clone(&self.buyer),
                escrow: ::core::clone::Clone::clone(&self.escrow),
            }
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountMetas for Dispute<'info> {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(anchor_lang::Key::key(&self.buyer),
                    is_signer.unwrap_or(true)));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.escrow),
                    false));
            account_metas
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountInfos<'info> for Dispute<'info> {
        fn to_account_infos(&self)
            ->
                Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
            let mut account_infos = ::alloc::vec::Vec::new();
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.buyer));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.escrow));
            account_infos
        }
    }
}
pub struct Finalize<'info> {
    #[account(seeds = [b"config"], bump = config.bump, has_one = platform)]
    pub config: Account<'info, Config>,
    #[account(mut, seeds = [b"escrow", escrow.booking.as_ref()], bump =
    escrow.bump, has_one = buyer, has_one = provider, close = buyer)]
    pub escrow: Account<'info, Escrow>,
    /// CHECK: constrained by escrow and receives refund plus closed-account rent.
    #[account(mut)]
    pub buyer: UncheckedAccount<'info>,
    /// CHECK: constrained by escrow.
    #[account(mut)]
    pub provider: UncheckedAccount<'info>,
    /// CHECK: constrained by config.
    #[account(mut)]
    pub platform: UncheckedAccount<'info>,
}
#[automatically_derived]
impl<'info> Finalize<'info> where 'info: 'info {
    #[doc(hidden)]
    pub const __ANCHOR_IX_PARAM_COUNT: usize = 0;
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_0<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_1<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_2<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_3<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_4<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_5<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_6<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_7<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_8<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_9<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_10<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_11<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_12<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_13<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_14<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_15<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_16<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_17<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_18<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_19<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_20<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_21<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_22<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_23<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_24<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_25<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_26<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_27<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_28<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_29<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_30<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_31<__T>(_arg: &__T) {}
}
#[automatically_derived]
impl<'info> anchor_lang::Accounts<'info, FinalizeBumps> for Finalize<'info>
    where 'info: 'info {
    #[inline(never)]
    fn try_accounts(__program_id:
            &anchor_lang::solana_program::pubkey::Pubkey,
        __accounts:
            &mut &'info [anchor_lang::solana_program::account_info::AccountInfo<'info>],
        __ix_data: &[u8], __bumps: &mut FinalizeBumps,
        __reallocs:
            &mut ::std::collections::BTreeSet<anchor_lang::solana_program::pubkey::Pubkey>)
        -> anchor_lang::Result<Self> {
        let config: anchor_lang::accounts::account::Account<Config> =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("config"))?;
        let escrow: anchor_lang::accounts::account::Account<Escrow> =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("escrow"))?;
        let buyer: UncheckedAccount =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("buyer"))?;
        let provider: UncheckedAccount =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("provider"))?;
        let platform: UncheckedAccount =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("platform"))?;
        {
            let mut __mutable_accounts = ::std::collections::HashSet::new();
            if let Some(key) = Some(escrow.key()) {
                if !__mutable_accounts.insert(key) {
                    return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintDuplicateMutableAccount).with_account_name("escrow"));
                }
            }
        }
        let __pda_address =
            Pubkey::create_program_address(&[b"config", &[config.bump][..]],
                        &__program_id).map_err(|_|
                        anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("config"))?;
        if config.key() != __pda_address {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("config").with_pubkeys((config.key(),
                            __pda_address)));
        }
        {
            let my_key = config.platform;
            let target_key = platform.key();
            if my_key != target_key {
                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintHasOne).with_account_name("config").with_pubkeys((my_key,
                                target_key)));
            }
        }
        let __pda_address =
            Pubkey::create_program_address(&[b"escrow",
                                    escrow.booking.as_ref(), &[escrow.bump][..]],
                        &__program_id).map_err(|_|
                        anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("escrow"))?;
        if escrow.key() != __pda_address {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("escrow").with_pubkeys((escrow.key(),
                            __pda_address)));
        }
        if !AsRef::<AccountInfo>::as_ref(&escrow).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("escrow"));
        }
        {
            let my_key = escrow.buyer;
            let target_key = buyer.key();
            if my_key != target_key {
                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintHasOne).with_account_name("escrow").with_pubkeys((my_key,
                                target_key)));
            }
        }
        {
            let my_key = escrow.provider;
            let target_key = provider.key();
            if my_key != target_key {
                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintHasOne).with_account_name("escrow").with_pubkeys((my_key,
                                target_key)));
            }
        }
        {
            if escrow.key() == buyer.key() {
                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintClose).with_account_name("escrow"));
            }
        }
        if !AsRef::<AccountInfo>::as_ref(&buyer).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("buyer"));
        }
        if !AsRef::<AccountInfo>::as_ref(&provider).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("provider"));
        }
        if !AsRef::<AccountInfo>::as_ref(&platform).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("platform"));
        }
        Ok(Finalize { config, escrow, buyer, provider, platform })
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountInfos<'info> for Finalize<'info> where
    'info: 'info {
    fn to_account_infos(&self)
        ->
            Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
        let mut account_infos = ::alloc::vec::Vec::new();
        account_infos.extend(self.config.to_account_infos());
        account_infos.extend(self.escrow.to_account_infos());
        account_infos.extend(self.buyer.to_account_infos());
        account_infos.extend(self.provider.to_account_infos());
        account_infos.extend(self.platform.to_account_infos());
        account_infos
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountMetas for Finalize<'info> {
    fn to_account_metas(&self, is_signer: Option<bool>)
        -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
        let mut account_metas = ::alloc::vec::Vec::new();
        account_metas.extend(self.config.to_account_metas(None));
        account_metas.extend(self.escrow.to_account_metas(None));
        account_metas.extend(self.buyer.to_account_metas(None));
        account_metas.extend(self.provider.to_account_metas(None));
        account_metas.extend(self.platform.to_account_metas(None));
        account_metas
    }
}
#[automatically_derived]
impl<'info> anchor_lang::AccountsExit<'info> for Finalize<'info> where
    'info: 'info {
    fn exit(&self, program_id: &anchor_lang::solana_program::pubkey::Pubkey)
        -> anchor_lang::Result<()> {
        {
            let buyer = &self.buyer;
            anchor_lang::AccountsClose::close(&self.escrow,
                        buyer.to_account_info()).map_err(|e|
                        e.with_account_name("escrow"))?;
        }
        anchor_lang::AccountsExit::exit(&self.buyer,
                    program_id).map_err(|e| e.with_account_name("buyer"))?;
        anchor_lang::AccountsExit::exit(&self.provider,
                    program_id).map_err(|e| e.with_account_name("provider"))?;
        anchor_lang::AccountsExit::exit(&self.platform,
                    program_id).map_err(|e| e.with_account_name("platform"))?;
        Ok(())
    }
}
#[automatically_derived]
impl<'info> anchor_lang::DuplicateMutableAccountKeys for Finalize<'info> where
    'info: 'info {
    fn duplicate_mutable_account_keys(&self)
        -> Vec<anchor_lang::solana_program::pubkey::Pubkey> {
        let mut keys = Vec::new();
        keys.push(self.escrow.key());
        keys
    }
}
#[automatically_derived]
impl<'info> Finalize<'info> where 'info: 'info {
    #[doc(hidden)]
    #[inline(always)]
    pub unsafe fn __shorten_invariant_lifetime<'__a,
        '__info: '__a>(value: &'__a mut Finalize<'__info>)
        -> &'__a mut Finalize<'__a> {
        unsafe { ::core::mem::transmute(value) }
    }
}
pub struct FinalizeBumps {}
#[automatically_derived]
impl ::core::fmt::Debug for FinalizeBumps {
    #[inline]
    fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
        ::core::fmt::Formatter::write_str(f, "FinalizeBumps")
    }
}
#[automatically_derived]
#[doc(hidden)]
unsafe impl ::core::clone::TrivialClone for FinalizeBumps { }
#[automatically_derived]
impl ::core::clone::Clone for FinalizeBumps {
    #[inline]
    fn clone(&self) -> FinalizeBumps { *self }
}
#[automatically_derived]
impl ::core::marker::Copy for FinalizeBumps { }
impl Default for FinalizeBumps {
    fn default() -> Self { FinalizeBumps {} }
}
impl<'info> anchor_lang::Bumps for Finalize<'info> where 'info: 'info {
    type Bumps = FinalizeBumps;
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a struct for a given"]
#[doc =
r" `#[derive(Accounts)]` implementation, where each field is a Pubkey,"]
#[doc = r" instead of an `AccountInfo`. This is useful for clients that want"]
#[doc = r" to generate a list of accounts, without explicitly knowing the"]
#[doc = r" order all the fields should be in."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" `accounts` module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __client_accounts_finalize {
    use super::*;
    use anchor_lang::prelude::borsh;
    #[doc = " Generated client accounts for [`Finalize`]."]
    pub struct Finalize {
        pub config: Pubkey,
        pub escrow: Pubkey,
        pub buyer: Pubkey,
        pub provider: Pubkey,
        pub platform: Pubkey,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for Finalize {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.config,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.escrow,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.buyer,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.provider,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.platform,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for Finalize {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field5_finish(f, "Finalize",
                "config", &self.config, "escrow", &self.escrow, "buyer",
                &self.buyer, "provider", &self.provider, "platform",
                &&self.platform)
        }
    }
    #[automatically_derived]
    impl ::core::default::Default for Finalize {
        #[inline]
        fn default() -> Finalize {
            Finalize {
                config: ::core::default::Default::default(),
                escrow: ::core::default::Default::default(),
                buyer: ::core::default::Default::default(),
                provider: ::core::default::Default::default(),
                platform: ::core::default::Default::default(),
            }
        }
    }
    #[automatically_derived]
    impl ::core::marker::Copy for Finalize { }
    #[automatically_derived]
    #[doc(hidden)]
    unsafe impl ::core::clone::TrivialClone for Finalize { }
    #[automatically_derived]
    impl ::core::clone::Clone for Finalize {
        #[inline]
        fn clone(&self) -> Finalize {
            let _: ::core::clone::AssertParamIsClone<Pubkey>;
            *self
        }
    }
    #[automatically_derived]
    impl anchor_lang::ToAccountMetas for Finalize {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(self.config,
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.escrow,
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.buyer,
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.provider,
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.platform,
                    false));
            account_metas
        }
    }
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a CPI struct for a given"]
#[doc = r" `#[derive(Accounts)]` implementation, where each field is an"]
#[doc = r" AccountInfo."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" [`cpi::accounts`] module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __cpi_client_accounts_finalize {
    use super::*;
    #[doc = " Generated CPI struct of the accounts for [`Finalize`]."]
    pub struct Finalize<'info> {
        pub config: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub escrow: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub buyer: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub provider: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub platform: anchor_lang::solana_program::account_info::AccountInfo<'info>,
    }
    #[automatically_derived]
    impl<'info> ::core::fmt::Debug for Finalize<'info> {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field5_finish(f, "Finalize",
                "config", &self.config, "escrow", &self.escrow, "buyer",
                &self.buyer, "provider", &self.provider, "platform",
                &&self.platform)
        }
    }
    #[automatically_derived]
    impl<'info> ::core::clone::Clone for Finalize<'info> {
        #[inline]
        fn clone(&self) -> Finalize<'info> {
            Finalize {
                config: ::core::clone::Clone::clone(&self.config),
                escrow: ::core::clone::Clone::clone(&self.escrow),
                buyer: ::core::clone::Clone::clone(&self.buyer),
                provider: ::core::clone::Clone::clone(&self.provider),
                platform: ::core::clone::Clone::clone(&self.platform),
            }
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountMetas for Finalize<'info> {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(anchor_lang::Key::key(&self.config),
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.escrow),
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.buyer),
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.provider),
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.platform),
                    false));
            account_metas
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountInfos<'info> for Finalize<'info> {
        fn to_account_infos(&self)
            ->
                Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
            let mut account_infos = ::alloc::vec::Vec::new();
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.config));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.escrow));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.buyer));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.provider));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.platform));
            account_infos
        }
    }
}
pub struct ResolveDispute<'info> {
    #[account(seeds = [b"config"], bump = config.bump, has_one = admin,
    has_one = platform)]
    pub config: Account<'info, Config>,
    pub admin: Signer<'info>,
    #[account(mut, seeds = [b"escrow", escrow.booking.as_ref()], bump =
    escrow.bump, has_one = buyer, has_one = provider, close = buyer)]
    pub escrow: Account<'info, Escrow>,
    /// CHECK: constrained by escrow.
    #[account(mut)]
    pub buyer: UncheckedAccount<'info>,
    /// CHECK: constrained by escrow.
    #[account(mut)]
    pub provider: UncheckedAccount<'info>,
    /// CHECK: constrained by config.
    #[account(mut)]
    pub platform: UncheckedAccount<'info>,
}
#[automatically_derived]
impl<'info> ResolveDispute<'info> where 'info: 'info {
    #[doc(hidden)]
    pub const __ANCHOR_IX_PARAM_COUNT: usize = 0;
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_0<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_1<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_2<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_3<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_4<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_5<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_6<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_7<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_8<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_9<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_10<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_11<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_12<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_13<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_14<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_15<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_16<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_17<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_18<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_19<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_20<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_21<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_22<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_23<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_24<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_25<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_26<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_27<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_28<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_29<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_30<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_31<__T>(_arg: &__T) {}
}
#[automatically_derived]
impl<'info> anchor_lang::Accounts<'info, ResolveDisputeBumps> for
    ResolveDispute<'info> where 'info: 'info {
    #[inline(never)]
    fn try_accounts(__program_id:
            &anchor_lang::solana_program::pubkey::Pubkey,
        __accounts:
            &mut &'info [anchor_lang::solana_program::account_info::AccountInfo<'info>],
        __ix_data: &[u8], __bumps: &mut ResolveDisputeBumps,
        __reallocs:
            &mut ::std::collections::BTreeSet<anchor_lang::solana_program::pubkey::Pubkey>)
        -> anchor_lang::Result<Self> {
        let config: anchor_lang::accounts::account::Account<Config> =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("config"))?;
        let admin: Signer =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("admin"))?;
        let escrow: anchor_lang::accounts::account::Account<Escrow> =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("escrow"))?;
        let buyer: UncheckedAccount =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("buyer"))?;
        let provider: UncheckedAccount =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("provider"))?;
        let platform: UncheckedAccount =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("platform"))?;
        {
            let mut __mutable_accounts = ::std::collections::HashSet::new();
            if let Some(key) = Some(escrow.key()) {
                if !__mutable_accounts.insert(key) {
                    return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintDuplicateMutableAccount).with_account_name("escrow"));
                }
            }
        }
        let __pda_address =
            Pubkey::create_program_address(&[b"config", &[config.bump][..]],
                        &__program_id).map_err(|_|
                        anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("config"))?;
        if config.key() != __pda_address {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("config").with_pubkeys((config.key(),
                            __pda_address)));
        }
        {
            let my_key = config.admin;
            let target_key = admin.key();
            if my_key != target_key {
                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintHasOne).with_account_name("config").with_pubkeys((my_key,
                                target_key)));
            }
        }
        {
            let my_key = config.platform;
            let target_key = platform.key();
            if my_key != target_key {
                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintHasOne).with_account_name("config").with_pubkeys((my_key,
                                target_key)));
            }
        }
        let __pda_address =
            Pubkey::create_program_address(&[b"escrow",
                                    escrow.booking.as_ref(), &[escrow.bump][..]],
                        &__program_id).map_err(|_|
                        anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("escrow"))?;
        if escrow.key() != __pda_address {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("escrow").with_pubkeys((escrow.key(),
                            __pda_address)));
        }
        if !AsRef::<AccountInfo>::as_ref(&escrow).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("escrow"));
        }
        {
            let my_key = escrow.buyer;
            let target_key = buyer.key();
            if my_key != target_key {
                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintHasOne).with_account_name("escrow").with_pubkeys((my_key,
                                target_key)));
            }
        }
        {
            let my_key = escrow.provider;
            let target_key = provider.key();
            if my_key != target_key {
                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintHasOne).with_account_name("escrow").with_pubkeys((my_key,
                                target_key)));
            }
        }
        {
            if escrow.key() == buyer.key() {
                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintClose).with_account_name("escrow"));
            }
        }
        if !AsRef::<AccountInfo>::as_ref(&buyer).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("buyer"));
        }
        if !AsRef::<AccountInfo>::as_ref(&provider).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("provider"));
        }
        if !AsRef::<AccountInfo>::as_ref(&platform).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("platform"));
        }
        Ok(ResolveDispute {
                config,
                admin,
                escrow,
                buyer,
                provider,
                platform,
            })
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountInfos<'info> for ResolveDispute<'info> where
    'info: 'info {
    fn to_account_infos(&self)
        ->
            Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
        let mut account_infos = ::alloc::vec::Vec::new();
        account_infos.extend(self.config.to_account_infos());
        account_infos.extend(self.admin.to_account_infos());
        account_infos.extend(self.escrow.to_account_infos());
        account_infos.extend(self.buyer.to_account_infos());
        account_infos.extend(self.provider.to_account_infos());
        account_infos.extend(self.platform.to_account_infos());
        account_infos
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountMetas for ResolveDispute<'info> {
    fn to_account_metas(&self, is_signer: Option<bool>)
        -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
        let mut account_metas = ::alloc::vec::Vec::new();
        account_metas.extend(self.config.to_account_metas(None));
        account_metas.extend(self.admin.to_account_metas(None));
        account_metas.extend(self.escrow.to_account_metas(None));
        account_metas.extend(self.buyer.to_account_metas(None));
        account_metas.extend(self.provider.to_account_metas(None));
        account_metas.extend(self.platform.to_account_metas(None));
        account_metas
    }
}
#[automatically_derived]
impl<'info> anchor_lang::AccountsExit<'info> for ResolveDispute<'info> where
    'info: 'info {
    fn exit(&self, program_id: &anchor_lang::solana_program::pubkey::Pubkey)
        -> anchor_lang::Result<()> {
        {
            let buyer = &self.buyer;
            anchor_lang::AccountsClose::close(&self.escrow,
                        buyer.to_account_info()).map_err(|e|
                        e.with_account_name("escrow"))?;
        }
        anchor_lang::AccountsExit::exit(&self.buyer,
                    program_id).map_err(|e| e.with_account_name("buyer"))?;
        anchor_lang::AccountsExit::exit(&self.provider,
                    program_id).map_err(|e| e.with_account_name("provider"))?;
        anchor_lang::AccountsExit::exit(&self.platform,
                    program_id).map_err(|e| e.with_account_name("platform"))?;
        Ok(())
    }
}
#[automatically_derived]
impl<'info> anchor_lang::DuplicateMutableAccountKeys for ResolveDispute<'info>
    where 'info: 'info {
    fn duplicate_mutable_account_keys(&self)
        -> Vec<anchor_lang::solana_program::pubkey::Pubkey> {
        let mut keys = Vec::new();
        keys.push(self.escrow.key());
        keys
    }
}
#[automatically_derived]
impl<'info> ResolveDispute<'info> where 'info: 'info {
    #[doc(hidden)]
    #[inline(always)]
    pub unsafe fn __shorten_invariant_lifetime<'__a,
        '__info: '__a>(value: &'__a mut ResolveDispute<'__info>)
        -> &'__a mut ResolveDispute<'__a> {
        unsafe { ::core::mem::transmute(value) }
    }
}
pub struct ResolveDisputeBumps {}
#[automatically_derived]
impl ::core::fmt::Debug for ResolveDisputeBumps {
    #[inline]
    fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
        ::core::fmt::Formatter::write_str(f, "ResolveDisputeBumps")
    }
}
#[automatically_derived]
#[doc(hidden)]
unsafe impl ::core::clone::TrivialClone for ResolveDisputeBumps { }
#[automatically_derived]
impl ::core::clone::Clone for ResolveDisputeBumps {
    #[inline]
    fn clone(&self) -> ResolveDisputeBumps { *self }
}
#[automatically_derived]
impl ::core::marker::Copy for ResolveDisputeBumps { }
impl Default for ResolveDisputeBumps {
    fn default() -> Self { ResolveDisputeBumps {} }
}
impl<'info> anchor_lang::Bumps for ResolveDispute<'info> where 'info: 'info {
    type Bumps = ResolveDisputeBumps;
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a struct for a given"]
#[doc =
r" `#[derive(Accounts)]` implementation, where each field is a Pubkey,"]
#[doc = r" instead of an `AccountInfo`. This is useful for clients that want"]
#[doc = r" to generate a list of accounts, without explicitly knowing the"]
#[doc = r" order all the fields should be in."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" `accounts` module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __client_accounts_resolve_dispute {
    use super::*;
    use anchor_lang::prelude::borsh;
    #[doc = " Generated client accounts for [`ResolveDispute`]."]
    pub struct ResolveDispute {
        pub config: Pubkey,
        pub admin: Pubkey,
        pub escrow: Pubkey,
        pub buyer: Pubkey,
        pub provider: Pubkey,
        pub platform: Pubkey,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for ResolveDispute {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.config,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.admin,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.escrow,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.buyer,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.provider,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.platform,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for ResolveDispute {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            let names: &'static _ =
                &["config", "admin", "escrow", "buyer", "provider",
                            "platform"];
            let values: &[&dyn ::core::fmt::Debug] =
                &[&self.config, &self.admin, &self.escrow, &self.buyer,
                            &self.provider, &&self.platform];
            ::core::fmt::Formatter::debug_struct_fields_finish(f,
                "ResolveDispute", names, values)
        }
    }
    #[automatically_derived]
    impl ::core::default::Default for ResolveDispute {
        #[inline]
        fn default() -> ResolveDispute {
            ResolveDispute {
                config: ::core::default::Default::default(),
                admin: ::core::default::Default::default(),
                escrow: ::core::default::Default::default(),
                buyer: ::core::default::Default::default(),
                provider: ::core::default::Default::default(),
                platform: ::core::default::Default::default(),
            }
        }
    }
    #[automatically_derived]
    impl ::core::marker::Copy for ResolveDispute { }
    #[automatically_derived]
    #[doc(hidden)]
    unsafe impl ::core::clone::TrivialClone for ResolveDispute { }
    #[automatically_derived]
    impl ::core::clone::Clone for ResolveDispute {
        #[inline]
        fn clone(&self) -> ResolveDispute {
            let _: ::core::clone::AssertParamIsClone<Pubkey>;
            *self
        }
    }
    #[automatically_derived]
    impl anchor_lang::ToAccountMetas for ResolveDispute {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(self.config,
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(self.admin,
                    is_signer.unwrap_or(true)));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.escrow,
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.buyer,
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.provider,
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.platform,
                    false));
            account_metas
        }
    }
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a CPI struct for a given"]
#[doc = r" `#[derive(Accounts)]` implementation, where each field is an"]
#[doc = r" AccountInfo."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" [`cpi::accounts`] module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __cpi_client_accounts_resolve_dispute {
    use super::*;
    #[doc = " Generated CPI struct of the accounts for [`ResolveDispute`]."]
    pub struct ResolveDispute<'info> {
        pub config: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub admin: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub escrow: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub buyer: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub provider: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub platform: anchor_lang::solana_program::account_info::AccountInfo<'info>,
    }
    #[automatically_derived]
    impl<'info> ::core::fmt::Debug for ResolveDispute<'info> {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            let names: &'static _ =
                &["config", "admin", "escrow", "buyer", "provider",
                            "platform"];
            let values: &[&dyn ::core::fmt::Debug] =
                &[&self.config, &self.admin, &self.escrow, &self.buyer,
                            &self.provider, &&self.platform];
            ::core::fmt::Formatter::debug_struct_fields_finish(f,
                "ResolveDispute", names, values)
        }
    }
    #[automatically_derived]
    impl<'info> ::core::clone::Clone for ResolveDispute<'info> {
        #[inline]
        fn clone(&self) -> ResolveDispute<'info> {
            ResolveDispute {
                config: ::core::clone::Clone::clone(&self.config),
                admin: ::core::clone::Clone::clone(&self.admin),
                escrow: ::core::clone::Clone::clone(&self.escrow),
                buyer: ::core::clone::Clone::clone(&self.buyer),
                provider: ::core::clone::Clone::clone(&self.provider),
                platform: ::core::clone::Clone::clone(&self.platform),
            }
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountMetas for ResolveDispute<'info> {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(anchor_lang::Key::key(&self.config),
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new_readonly(anchor_lang::Key::key(&self.admin),
                    is_signer.unwrap_or(true)));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.escrow),
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.buyer),
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.provider),
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.platform),
                    false));
            account_metas
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountInfos<'info> for ResolveDispute<'info> {
        fn to_account_infos(&self)
            ->
                Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
            let mut account_infos = ::alloc::vec::Vec::new();
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.config));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.admin));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.escrow));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.buyer));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.provider));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.platform));
            account_infos
        }
    }
}
pub struct RefundExpired<'info> {
    #[account(mut, seeds = [b"escrow", escrow.booking.as_ref()], bump =
    escrow.bump, has_one = buyer, close = buyer)]
    pub escrow: Account<'info, Escrow>,
    /// CHECK: constrained by escrow and receives refund plus closed-account rent.
    #[account(mut)]
    pub buyer: UncheckedAccount<'info>,
}
#[automatically_derived]
impl<'info> RefundExpired<'info> where 'info: 'info {
    #[doc(hidden)]
    pub const __ANCHOR_IX_PARAM_COUNT: usize = 0;
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_0<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_1<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_2<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_3<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_4<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_5<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_6<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_7<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_8<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_9<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_10<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_11<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_12<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_13<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_14<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_15<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_16<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_17<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_18<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_19<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_20<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_21<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_22<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_23<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_24<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_25<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_26<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_27<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_28<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_29<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_30<__T>(_arg: &__T) {}
    #[doc(hidden)]
    #[inline(always)]
    #[allow(unused)]
    pub fn __anchor_validate_ix_arg_type_31<__T>(_arg: &__T) {}
}
#[automatically_derived]
impl<'info> anchor_lang::Accounts<'info, RefundExpiredBumps> for
    RefundExpired<'info> where 'info: 'info {
    #[inline(never)]
    fn try_accounts(__program_id:
            &anchor_lang::solana_program::pubkey::Pubkey,
        __accounts:
            &mut &'info [anchor_lang::solana_program::account_info::AccountInfo<'info>],
        __ix_data: &[u8], __bumps: &mut RefundExpiredBumps,
        __reallocs:
            &mut ::std::collections::BTreeSet<anchor_lang::solana_program::pubkey::Pubkey>)
        -> anchor_lang::Result<Self> {
        let escrow: anchor_lang::accounts::account::Account<Escrow> =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("escrow"))?;
        let buyer: UncheckedAccount =
            anchor_lang::Accounts::try_accounts(__program_id, __accounts,
                        __ix_data, __bumps,
                        __reallocs).map_err(|e| e.with_account_name("buyer"))?;
        {
            let mut __mutable_accounts = ::std::collections::HashSet::new();
            if let Some(key) = Some(escrow.key()) {
                if !__mutable_accounts.insert(key) {
                    return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintDuplicateMutableAccount).with_account_name("escrow"));
                }
            }
        }
        let __pda_address =
            Pubkey::create_program_address(&[b"escrow",
                                    escrow.booking.as_ref(), &[escrow.bump][..]],
                        &__program_id).map_err(|_|
                        anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("escrow"))?;
        if escrow.key() != __pda_address {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintSeeds).with_account_name("escrow").with_pubkeys((escrow.key(),
                            __pda_address)));
        }
        if !AsRef::<AccountInfo>::as_ref(&escrow).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("escrow"));
        }
        {
            let my_key = escrow.buyer;
            let target_key = buyer.key();
            if my_key != target_key {
                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintHasOne).with_account_name("escrow").with_pubkeys((my_key,
                                target_key)));
            }
        }
        {
            if escrow.key() == buyer.key() {
                return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintClose).with_account_name("escrow"));
            }
        }
        if !AsRef::<AccountInfo>::as_ref(&buyer).is_writable {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::ErrorCode::ConstraintMut).with_account_name("buyer"));
        }
        Ok(RefundExpired { escrow, buyer })
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountInfos<'info> for RefundExpired<'info> where
    'info: 'info {
    fn to_account_infos(&self)
        ->
            Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
        let mut account_infos = ::alloc::vec::Vec::new();
        account_infos.extend(self.escrow.to_account_infos());
        account_infos.extend(self.buyer.to_account_infos());
        account_infos
    }
}
#[automatically_derived]
impl<'info> anchor_lang::ToAccountMetas for RefundExpired<'info> {
    fn to_account_metas(&self, is_signer: Option<bool>)
        -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
        let mut account_metas = ::alloc::vec::Vec::new();
        account_metas.extend(self.escrow.to_account_metas(None));
        account_metas.extend(self.buyer.to_account_metas(None));
        account_metas
    }
}
#[automatically_derived]
impl<'info> anchor_lang::AccountsExit<'info> for RefundExpired<'info> where
    'info: 'info {
    fn exit(&self, program_id: &anchor_lang::solana_program::pubkey::Pubkey)
        -> anchor_lang::Result<()> {
        {
            let buyer = &self.buyer;
            anchor_lang::AccountsClose::close(&self.escrow,
                        buyer.to_account_info()).map_err(|e|
                        e.with_account_name("escrow"))?;
        }
        anchor_lang::AccountsExit::exit(&self.buyer,
                    program_id).map_err(|e| e.with_account_name("buyer"))?;
        Ok(())
    }
}
#[automatically_derived]
impl<'info> anchor_lang::DuplicateMutableAccountKeys for RefundExpired<'info>
    where 'info: 'info {
    fn duplicate_mutable_account_keys(&self)
        -> Vec<anchor_lang::solana_program::pubkey::Pubkey> {
        let mut keys = Vec::new();
        keys.push(self.escrow.key());
        keys
    }
}
#[automatically_derived]
impl<'info> RefundExpired<'info> where 'info: 'info {
    #[doc(hidden)]
    #[inline(always)]
    pub unsafe fn __shorten_invariant_lifetime<'__a,
        '__info: '__a>(value: &'__a mut RefundExpired<'__info>)
        -> &'__a mut RefundExpired<'__a> {
        unsafe { ::core::mem::transmute(value) }
    }
}
pub struct RefundExpiredBumps {}
#[automatically_derived]
impl ::core::fmt::Debug for RefundExpiredBumps {
    #[inline]
    fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
        ::core::fmt::Formatter::write_str(f, "RefundExpiredBumps")
    }
}
#[automatically_derived]
#[doc(hidden)]
unsafe impl ::core::clone::TrivialClone for RefundExpiredBumps { }
#[automatically_derived]
impl ::core::clone::Clone for RefundExpiredBumps {
    #[inline]
    fn clone(&self) -> RefundExpiredBumps { *self }
}
#[automatically_derived]
impl ::core::marker::Copy for RefundExpiredBumps { }
impl Default for RefundExpiredBumps {
    fn default() -> Self { RefundExpiredBumps {} }
}
impl<'info> anchor_lang::Bumps for RefundExpired<'info> where 'info: 'info {
    type Bumps = RefundExpiredBumps;
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a struct for a given"]
#[doc =
r" `#[derive(Accounts)]` implementation, where each field is a Pubkey,"]
#[doc = r" instead of an `AccountInfo`. This is useful for clients that want"]
#[doc = r" to generate a list of accounts, without explicitly knowing the"]
#[doc = r" order all the fields should be in."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" `accounts` module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __client_accounts_refund_expired {
    use super::*;
    use anchor_lang::prelude::borsh;
    #[doc = " Generated client accounts for [`RefundExpired`]."]
    pub struct RefundExpired {
        pub escrow: Pubkey,
        pub buyer: Pubkey,
    }
    #[automatically_derived]
    impl anchor_lang::prelude::borsh::ser::BorshSerialize for RefundExpired {
        fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
            writer: &mut __W)
            ->
                ::core::result::Result<(),
                anchor_lang::prelude::borsh::io::Error> {
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.escrow,
                    writer)?;
            anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.buyer,
                    writer)?;
            Ok(())
        }
    }
    #[automatically_derived]
    impl ::core::fmt::Debug for RefundExpired {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field2_finish(f,
                "RefundExpired", "escrow", &self.escrow, "buyer",
                &&self.buyer)
        }
    }
    #[automatically_derived]
    impl ::core::default::Default for RefundExpired {
        #[inline]
        fn default() -> RefundExpired {
            RefundExpired {
                escrow: ::core::default::Default::default(),
                buyer: ::core::default::Default::default(),
            }
        }
    }
    #[automatically_derived]
    impl ::core::marker::Copy for RefundExpired { }
    #[automatically_derived]
    #[doc(hidden)]
    unsafe impl ::core::clone::TrivialClone for RefundExpired { }
    #[automatically_derived]
    impl ::core::clone::Clone for RefundExpired {
        #[inline]
        fn clone(&self) -> RefundExpired {
            let _: ::core::clone::AssertParamIsClone<Pubkey>;
            *self
        }
    }
    #[automatically_derived]
    impl anchor_lang::ToAccountMetas for RefundExpired {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.escrow,
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(self.buyer,
                    false));
            account_metas
        }
    }
}
#[doc = r" An internal, Anchor generated module. This is used (as an"]
#[doc = r" implementation detail), to generate a CPI struct for a given"]
#[doc = r" `#[derive(Accounts)]` implementation, where each field is an"]
#[doc = r" AccountInfo."]
#[doc = r""]
#[doc = r" To access the struct in this module, one should use the sibling"]
#[doc = r" [`cpi::accounts`] module (also generated), which re-exports this."]
#[doc(hidden)]
pub mod __cpi_client_accounts_refund_expired {
    use super::*;
    #[doc = " Generated CPI struct of the accounts for [`RefundExpired`]."]
    pub struct RefundExpired<'info> {
        pub escrow: anchor_lang::solana_program::account_info::AccountInfo<'info>,
        pub buyer: anchor_lang::solana_program::account_info::AccountInfo<'info>,
    }
    #[automatically_derived]
    impl<'info> ::core::fmt::Debug for RefundExpired<'info> {
        #[inline]
        fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
            ::core::fmt::Formatter::debug_struct_field2_finish(f,
                "RefundExpired", "escrow", &self.escrow, "buyer",
                &&self.buyer)
        }
    }
    #[automatically_derived]
    impl<'info> ::core::clone::Clone for RefundExpired<'info> {
        #[inline]
        fn clone(&self) -> RefundExpired<'info> {
            RefundExpired {
                escrow: ::core::clone::Clone::clone(&self.escrow),
                buyer: ::core::clone::Clone::clone(&self.buyer),
            }
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountMetas for RefundExpired<'info> {
        fn to_account_metas(&self, is_signer: Option<bool>)
            -> Vec<anchor_lang::solana_program::instruction::AccountMeta> {
            let mut account_metas = ::alloc::vec::Vec::new();
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.escrow),
                    false));
            account_metas.push(anchor_lang::solana_program::instruction::AccountMeta::new(anchor_lang::Key::key(&self.buyer),
                    false));
            account_metas
        }
    }
    #[automatically_derived]
    impl<'info> anchor_lang::ToAccountInfos<'info> for RefundExpired<'info> {
        fn to_account_infos(&self)
            ->
                Vec<anchor_lang::solana_program::account_info::AccountInfo<'info>> {
            let mut account_infos = ::alloc::vec::Vec::new();
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.escrow));
            account_infos.extend(anchor_lang::ToAccountInfos::to_account_infos(&self.buyer));
            account_infos
        }
    }
}
pub struct Config {
    pub admin: Pubkey,
    pub pending_admin: Pubkey,
    pub platform: Pubkey,
    pub oracle: Pubkey,
    pub paused: bool,
    pub bump: u8,
}
#[automatically_derived]
impl anchor_lang::Space for Config {
    const INIT_SPACE: usize = 0 + 32 + 32 + 32 + 32 + 1 + 1;
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::ser::BorshSerialize for Config {
    fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
        writer: &mut __W)
        ->
            ::core::result::Result<(),
            anchor_lang::prelude::borsh::io::Error> {
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.admin,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.pending_admin,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.platform,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.oracle,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.paused,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.bump,
                writer)?;
        Ok(())
    }
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::de::BorshDeserialize for Config {
    fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
            &mut __R)
        ->
            ::core::result::Result<Self,
            anchor_lang::prelude::borsh::io::Error> {
        Ok(Self {
                admin: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                pending_admin: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                platform: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                oracle: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                paused: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                bump: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
            })
    }
}
#[automatically_derived]
impl ::core::clone::Clone for Config {
    #[inline]
    fn clone(&self) -> Config {
        Config {
            admin: ::core::clone::Clone::clone(&self.admin),
            pending_admin: ::core::clone::Clone::clone(&self.pending_admin),
            platform: ::core::clone::Clone::clone(&self.platform),
            oracle: ::core::clone::Clone::clone(&self.oracle),
            paused: ::core::clone::Clone::clone(&self.paused),
            bump: ::core::clone::Clone::clone(&self.bump),
        }
    }
}
#[automatically_derived]
impl anchor_lang::AccountSerialize for Config {
    fn try_serialize<W: ::std::io::Write>(&self, writer: &mut W)
        -> anchor_lang::Result<()> {
        if writer.write_all(Config::DISCRIMINATOR).is_err() {
            return Err(anchor_lang::error::ErrorCode::AccountDidNotSerialize.into());
        }
        if AnchorSerialize::serialize(self, writer).is_err() {
            return Err(anchor_lang::error::ErrorCode::AccountDidNotSerialize.into());
        }
        Ok(())
    }
}
#[automatically_derived]
impl anchor_lang::AccountDeserialize for Config {
    fn try_deserialize(buf: &mut &[u8]) -> anchor_lang::Result<Self> {
        if buf.len() < Config::DISCRIMINATOR.len() {
            return Err(anchor_lang::error::ErrorCode::AccountDiscriminatorNotFound.into());
        }
        let given_disc = &buf[..Config::DISCRIMINATOR.len()];
        if Config::DISCRIMINATOR != given_disc {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                                error_name: anchor_lang::error::ErrorCode::AccountDiscriminatorMismatch.name(),
                                error_code_number: anchor_lang::error::ErrorCode::AccountDiscriminatorMismatch.into(),
                                error_msg: anchor_lang::error::ErrorCode::AccountDiscriminatorMismatch.to_string(),
                                error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                            filename: "programs/gpu_escrow/src/lib.rs",
                                            line: 251u32,
                                        })),
                                compared_values: None,
                            }).with_account_name("Config"));
        }
        Self::try_deserialize_unchecked(buf)
    }
    fn try_deserialize_unchecked(buf: &mut &[u8])
        -> anchor_lang::Result<Self> {
        let mut data: &[u8] = &buf[Config::DISCRIMINATOR.len()..];
        AnchorDeserialize::deserialize(&mut data).map_err(|_|
                anchor_lang::error::ErrorCode::AccountDidNotDeserialize.into())
    }
}
#[automatically_derived]
impl anchor_lang::Discriminator for Config {
    const DISCRIMINATOR: &'static [u8] =
        &[155, 12, 170, 224, 30, 250, 204, 130];
}
#[automatically_derived]
impl anchor_lang::Owner for Config {
    fn owner() -> Pubkey { { crate::ID } }
}
pub struct Escrow {
    pub booking: [u8; 32],
    pub buyer: Pubkey,
    pub provider: Pubkey,
    pub amount: u64,
    pub expected_seconds: u32,
    pub valid_seconds: u32,
    pub expires_at: i64,
    pub settle_after: i64,
    pub state: u8,
    pub bump: u8,
}
#[automatically_derived]
impl anchor_lang::Space for Escrow {
    const INIT_SPACE: usize =
        0 + (32 * 1) + 32 + 32 + 8 + 4 + 4 + 8 + 8 + 1 + 1;
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::ser::BorshSerialize for Escrow {
    fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
        writer: &mut __W)
        ->
            ::core::result::Result<(),
            anchor_lang::prelude::borsh::io::Error> {
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.booking,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.buyer,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.provider,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.amount,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.expected_seconds,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.valid_seconds,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.expires_at,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.settle_after,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.state,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.bump,
                writer)?;
        Ok(())
    }
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::de::BorshDeserialize for Escrow {
    fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
            &mut __R)
        ->
            ::core::result::Result<Self,
            anchor_lang::prelude::borsh::io::Error> {
        Ok(Self {
                booking: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                buyer: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                provider: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                amount: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                expected_seconds: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                valid_seconds: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                expires_at: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                settle_after: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                state: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                bump: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
            })
    }
}
#[automatically_derived]
impl ::core::clone::Clone for Escrow {
    #[inline]
    fn clone(&self) -> Escrow {
        Escrow {
            booking: ::core::clone::Clone::clone(&self.booking),
            buyer: ::core::clone::Clone::clone(&self.buyer),
            provider: ::core::clone::Clone::clone(&self.provider),
            amount: ::core::clone::Clone::clone(&self.amount),
            expected_seconds: ::core::clone::Clone::clone(&self.expected_seconds),
            valid_seconds: ::core::clone::Clone::clone(&self.valid_seconds),
            expires_at: ::core::clone::Clone::clone(&self.expires_at),
            settle_after: ::core::clone::Clone::clone(&self.settle_after),
            state: ::core::clone::Clone::clone(&self.state),
            bump: ::core::clone::Clone::clone(&self.bump),
        }
    }
}
#[automatically_derived]
impl anchor_lang::AccountSerialize for Escrow {
    fn try_serialize<W: ::std::io::Write>(&self, writer: &mut W)
        -> anchor_lang::Result<()> {
        if writer.write_all(Escrow::DISCRIMINATOR).is_err() {
            return Err(anchor_lang::error::ErrorCode::AccountDidNotSerialize.into());
        }
        if AnchorSerialize::serialize(self, writer).is_err() {
            return Err(anchor_lang::error::ErrorCode::AccountDidNotSerialize.into());
        }
        Ok(())
    }
}
#[automatically_derived]
impl anchor_lang::AccountDeserialize for Escrow {
    fn try_deserialize(buf: &mut &[u8]) -> anchor_lang::Result<Self> {
        if buf.len() < Escrow::DISCRIMINATOR.len() {
            return Err(anchor_lang::error::ErrorCode::AccountDiscriminatorNotFound.into());
        }
        let given_disc = &buf[..Escrow::DISCRIMINATOR.len()];
        if Escrow::DISCRIMINATOR != given_disc {
            return Err(anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                                error_name: anchor_lang::error::ErrorCode::AccountDiscriminatorMismatch.name(),
                                error_code_number: anchor_lang::error::ErrorCode::AccountDiscriminatorMismatch.into(),
                                error_msg: anchor_lang::error::ErrorCode::AccountDiscriminatorMismatch.to_string(),
                                error_origin: Some(anchor_lang::error::ErrorOrigin::Source(anchor_lang::error::Source {
                                            filename: "programs/gpu_escrow/src/lib.rs",
                                            line: 255u32,
                                        })),
                                compared_values: None,
                            }).with_account_name("Escrow"));
        }
        Self::try_deserialize_unchecked(buf)
    }
    fn try_deserialize_unchecked(buf: &mut &[u8])
        -> anchor_lang::Result<Self> {
        let mut data: &[u8] = &buf[Escrow::DISCRIMINATOR.len()..];
        AnchorDeserialize::deserialize(&mut data).map_err(|_|
                anchor_lang::error::ErrorCode::AccountDidNotDeserialize.into())
    }
}
#[automatically_derived]
impl anchor_lang::Discriminator for Escrow {
    const DISCRIMINATOR: &'static [u8] =
        &[31, 213, 123, 187, 186, 22, 218, 155];
}
#[automatically_derived]
impl anchor_lang::Owner for Escrow {
    fn owner() -> Pubkey { { crate::ID } }
}
#[repr(u8)]
pub enum EscrowState {
    Funded = 0,
    SettlementProposed = 1,
    Disputed = 2,
    Settled = 3,
    Refunded = 4,
}
pub struct ConfigInitialized {
    pub admin: Pubkey,
    pub platform: Pubkey,
    pub oracle: Pubkey,
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::ser::BorshSerialize for ConfigInitialized {
    fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
        writer: &mut __W)
        ->
            ::core::result::Result<(),
            anchor_lang::prelude::borsh::io::Error> {
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.admin,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.platform,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.oracle,
                writer)?;
        Ok(())
    }
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::de::BorshDeserialize for ConfigInitialized {
    fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
            &mut __R)
        ->
            ::core::result::Result<Self,
            anchor_lang::prelude::borsh::io::Error> {
        Ok(Self {
                admin: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                platform: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                oracle: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
            })
    }
}
impl anchor_lang::Event for ConfigInitialized {
    fn data(&self) -> Vec<u8> {
        let mut data = Vec::with_capacity(256);
        data.extend_from_slice(ConfigInitialized::DISCRIMINATOR);
        self.serialize(&mut data).unwrap();
        data
    }
}
impl anchor_lang::Discriminator for ConfigInitialized {
    const DISCRIMINATOR: &'static [u8] =
        &[181, 49, 200, 156, 19, 167, 178, 91];
}
pub struct ConfigUpdated {
    pub platform: Pubkey,
    pub oracle: Pubkey,
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::ser::BorshSerialize for ConfigUpdated {
    fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
        writer: &mut __W)
        ->
            ::core::result::Result<(),
            anchor_lang::prelude::borsh::io::Error> {
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.platform,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.oracle,
                writer)?;
        Ok(())
    }
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::de::BorshDeserialize for ConfigUpdated {
    fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
            &mut __R)
        ->
            ::core::result::Result<Self,
            anchor_lang::prelude::borsh::io::Error> {
        Ok(Self {
                platform: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                oracle: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
            })
    }
}
impl anchor_lang::Event for ConfigUpdated {
    fn data(&self) -> Vec<u8> {
        let mut data = Vec::with_capacity(256);
        data.extend_from_slice(ConfigUpdated::DISCRIMINATOR);
        self.serialize(&mut data).unwrap();
        data
    }
}
impl anchor_lang::Discriminator for ConfigUpdated {
    const DISCRIMINATOR: &'static [u8] =
        &[40, 241, 230, 122, 11, 19, 198, 194];
}
pub struct PauseChanged {
    pub paused: bool,
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::ser::BorshSerialize for PauseChanged {
    fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
        writer: &mut __W)
        ->
            ::core::result::Result<(),
            anchor_lang::prelude::borsh::io::Error> {
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.paused,
                writer)?;
        Ok(())
    }
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::de::BorshDeserialize for PauseChanged {
    fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
            &mut __R)
        ->
            ::core::result::Result<Self,
            anchor_lang::prelude::borsh::io::Error> {
        Ok(Self {
                paused: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
            })
    }
}
impl anchor_lang::Event for PauseChanged {
    fn data(&self) -> Vec<u8> {
        let mut data = Vec::with_capacity(256);
        data.extend_from_slice(PauseChanged::DISCRIMINATOR);
        self.serialize(&mut data).unwrap();
        data
    }
}
impl anchor_lang::Discriminator for PauseChanged {
    const DISCRIMINATOR: &'static [u8] =
        &[238, 188, 213, 78, 134, 209, 178, 218];
}
pub struct AdminTransferProposed {
    pub current_admin: Pubkey,
    pub pending_admin: Pubkey,
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::ser::BorshSerialize for
    AdminTransferProposed {
    fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
        writer: &mut __W)
        ->
            ::core::result::Result<(),
            anchor_lang::prelude::borsh::io::Error> {
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.current_admin,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.pending_admin,
                writer)?;
        Ok(())
    }
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::de::BorshDeserialize for
    AdminTransferProposed {
    fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
            &mut __R)
        ->
            ::core::result::Result<Self,
            anchor_lang::prelude::borsh::io::Error> {
        Ok(Self {
                current_admin: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                pending_admin: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
            })
    }
}
impl anchor_lang::Event for AdminTransferProposed {
    fn data(&self) -> Vec<u8> {
        let mut data = Vec::with_capacity(256);
        data.extend_from_slice(AdminTransferProposed::DISCRIMINATOR);
        self.serialize(&mut data).unwrap();
        data
    }
}
impl anchor_lang::Discriminator for AdminTransferProposed {
    const DISCRIMINATOR: &'static [u8] =
        &[203, 168, 175, 51, 239, 104, 20, 85];
}
pub struct AdminTransferred {
    pub previous_admin: Pubkey,
    pub new_admin: Pubkey,
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::ser::BorshSerialize for AdminTransferred {
    fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
        writer: &mut __W)
        ->
            ::core::result::Result<(),
            anchor_lang::prelude::borsh::io::Error> {
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.previous_admin,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.new_admin,
                writer)?;
        Ok(())
    }
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::de::BorshDeserialize for AdminTransferred {
    fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
            &mut __R)
        ->
            ::core::result::Result<Self,
            anchor_lang::prelude::borsh::io::Error> {
        Ok(Self {
                previous_admin: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                new_admin: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
            })
    }
}
impl anchor_lang::Event for AdminTransferred {
    fn data(&self) -> Vec<u8> {
        let mut data = Vec::with_capacity(256);
        data.extend_from_slice(AdminTransferred::DISCRIMINATOR);
        self.serialize(&mut data).unwrap();
        data
    }
}
impl anchor_lang::Discriminator for AdminTransferred {
    const DISCRIMINATOR: &'static [u8] =
        &[255, 147, 182, 5, 199, 217, 38, 179];
}
pub struct EscrowOpened {
    pub escrow: Pubkey,
    pub booking: [u8; 32],
    pub buyer: Pubkey,
    pub provider: Pubkey,
    pub amount: u64,
    pub expected_seconds: u32,
    pub expires_at: i64,
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::ser::BorshSerialize for EscrowOpened {
    fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
        writer: &mut __W)
        ->
            ::core::result::Result<(),
            anchor_lang::prelude::borsh::io::Error> {
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.escrow,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.booking,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.buyer,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.provider,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.amount,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.expected_seconds,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.expires_at,
                writer)?;
        Ok(())
    }
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::de::BorshDeserialize for EscrowOpened {
    fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
            &mut __R)
        ->
            ::core::result::Result<Self,
            anchor_lang::prelude::borsh::io::Error> {
        Ok(Self {
                escrow: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                booking: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                buyer: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                provider: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                amount: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                expected_seconds: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                expires_at: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
            })
    }
}
impl anchor_lang::Event for EscrowOpened {
    fn data(&self) -> Vec<u8> {
        let mut data = Vec::with_capacity(256);
        data.extend_from_slice(EscrowOpened::DISCRIMINATOR);
        self.serialize(&mut data).unwrap();
        data
    }
}
impl anchor_lang::Discriminator for EscrowOpened {
    const DISCRIMINATOR: &'static [u8] = &[201, 42, 96, 8, 123, 9, 212, 164];
}
pub struct SettlementProposed {
    pub escrow: Pubkey,
    pub valid_seconds: u32,
    pub settle_after: i64,
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::ser::BorshSerialize for SettlementProposed {
    fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
        writer: &mut __W)
        ->
            ::core::result::Result<(),
            anchor_lang::prelude::borsh::io::Error> {
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.escrow,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.valid_seconds,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.settle_after,
                writer)?;
        Ok(())
    }
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::de::BorshDeserialize for SettlementProposed
    {
    fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
            &mut __R)
        ->
            ::core::result::Result<Self,
            anchor_lang::prelude::borsh::io::Error> {
        Ok(Self {
                escrow: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                valid_seconds: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                settle_after: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
            })
    }
}
impl anchor_lang::Event for SettlementProposed {
    fn data(&self) -> Vec<u8> {
        let mut data = Vec::with_capacity(256);
        data.extend_from_slice(SettlementProposed::DISCRIMINATOR);
        self.serialize(&mut data).unwrap();
        data
    }
}
impl anchor_lang::Discriminator for SettlementProposed {
    const DISCRIMINATOR: &'static [u8] =
        &[139, 32, 64, 205, 27, 154, 100, 147];
}
pub struct EscrowDisputed {
    pub escrow: Pubkey,
    pub buyer: Pubkey,
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::ser::BorshSerialize for EscrowDisputed {
    fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
        writer: &mut __W)
        ->
            ::core::result::Result<(),
            anchor_lang::prelude::borsh::io::Error> {
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.escrow,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.buyer,
                writer)?;
        Ok(())
    }
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::de::BorshDeserialize for EscrowDisputed {
    fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
            &mut __R)
        ->
            ::core::result::Result<Self,
            anchor_lang::prelude::borsh::io::Error> {
        Ok(Self {
                escrow: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                buyer: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
            })
    }
}
impl anchor_lang::Event for EscrowDisputed {
    fn data(&self) -> Vec<u8> {
        let mut data = Vec::with_capacity(256);
        data.extend_from_slice(EscrowDisputed::DISCRIMINATOR);
        self.serialize(&mut data).unwrap();
        data
    }
}
impl anchor_lang::Discriminator for EscrowDisputed {
    const DISCRIMINATOR: &'static [u8] =
        &[132, 73, 81, 200, 177, 51, 128, 18];
}
pub struct EscrowSettled {
    pub escrow: Pubkey,
    pub payable: u64,
    pub platform_amount: u64,
    pub provider_amount: u64,
    pub refund: u64,
    pub valid_seconds: u32,
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::ser::BorshSerialize for EscrowSettled {
    fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
        writer: &mut __W)
        ->
            ::core::result::Result<(),
            anchor_lang::prelude::borsh::io::Error> {
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.escrow,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.payable,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.platform_amount,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.provider_amount,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.refund,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.valid_seconds,
                writer)?;
        Ok(())
    }
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::de::BorshDeserialize for EscrowSettled {
    fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
            &mut __R)
        ->
            ::core::result::Result<Self,
            anchor_lang::prelude::borsh::io::Error> {
        Ok(Self {
                escrow: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                payable: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                platform_amount: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                provider_amount: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                refund: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                valid_seconds: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
            })
    }
}
impl anchor_lang::Event for EscrowSettled {
    fn data(&self) -> Vec<u8> {
        let mut data = Vec::with_capacity(256);
        data.extend_from_slice(EscrowSettled::DISCRIMINATOR);
        self.serialize(&mut data).unwrap();
        data
    }
}
impl anchor_lang::Discriminator for EscrowSettled {
    const DISCRIMINATOR: &'static [u8] =
        &[97, 27, 150, 55, 203, 179, 173, 23];
}
pub struct EscrowRefunded {
    pub escrow: Pubkey,
    pub buyer: Pubkey,
    pub amount: u64,
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::ser::BorshSerialize for EscrowRefunded {
    fn serialize<__W: anchor_lang::prelude::borsh::io::Write>(&self,
        writer: &mut __W)
        ->
            ::core::result::Result<(),
            anchor_lang::prelude::borsh::io::Error> {
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.escrow,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.buyer,
                writer)?;
        anchor_lang::prelude::borsh::BorshSerialize::serialize(&self.amount,
                writer)?;
        Ok(())
    }
}
#[automatically_derived]
impl anchor_lang::prelude::borsh::de::BorshDeserialize for EscrowRefunded {
    fn deserialize_reader<__R: anchor_lang::prelude::borsh::io::Read>(reader:
            &mut __R)
        ->
            ::core::result::Result<Self,
            anchor_lang::prelude::borsh::io::Error> {
        Ok(Self {
                escrow: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                buyer: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
                amount: anchor_lang::prelude::borsh::BorshDeserialize::deserialize_reader(reader)?,
            })
    }
}
impl anchor_lang::Event for EscrowRefunded {
    fn data(&self) -> Vec<u8> {
        let mut data = Vec::with_capacity(256);
        data.extend_from_slice(EscrowRefunded::DISCRIMINATOR);
        self.serialize(&mut data).unwrap();
        data
    }
}
impl anchor_lang::Discriminator for EscrowRefunded {
    const DISCRIMINATOR: &'static [u8] =
        &[132, 209, 49, 109, 135, 138, 28, 81];
}
#[repr(u32)]
pub enum ErrorCode {
    Paused,
    InvalidInput,
    InvalidExpiry,
    InvalidState,
    TooEarly,
    Math,
    InvalidAddress,
    SelfBooking,
    DisputeWindowClosed,
    Unauthorized,
}
#[automatically_derived]
impl ::core::fmt::Debug for ErrorCode {
    #[inline]
    fn fmt(&self, f: &mut ::core::fmt::Formatter) -> ::core::fmt::Result {
        ::core::fmt::Formatter::write_str(f,
            match self {
                ErrorCode::Paused => "Paused",
                ErrorCode::InvalidInput => "InvalidInput",
                ErrorCode::InvalidExpiry => "InvalidExpiry",
                ErrorCode::InvalidState => "InvalidState",
                ErrorCode::TooEarly => "TooEarly",
                ErrorCode::Math => "Math",
                ErrorCode::InvalidAddress => "InvalidAddress",
                ErrorCode::SelfBooking => "SelfBooking",
                ErrorCode::DisputeWindowClosed => "DisputeWindowClosed",
                ErrorCode::Unauthorized => "Unauthorized",
            })
    }
}
#[automatically_derived]
#[doc(hidden)]
unsafe impl ::core::clone::TrivialClone for ErrorCode { }
#[automatically_derived]
impl ::core::clone::Clone for ErrorCode {
    #[inline]
    fn clone(&self) -> ErrorCode { *self }
}
#[automatically_derived]
impl ::core::marker::Copy for ErrorCode { }
impl ErrorCode {
    #[doc = r" Gets the name of this [#enum_name]."]
    pub fn name(&self) -> String {
        match self {
            ErrorCode::Paused => "Paused".to_string(),
            ErrorCode::InvalidInput => "InvalidInput".to_string(),
            ErrorCode::InvalidExpiry => "InvalidExpiry".to_string(),
            ErrorCode::InvalidState => "InvalidState".to_string(),
            ErrorCode::TooEarly => "TooEarly".to_string(),
            ErrorCode::Math => "Math".to_string(),
            ErrorCode::InvalidAddress => "InvalidAddress".to_string(),
            ErrorCode::SelfBooking => "SelfBooking".to_string(),
            ErrorCode::DisputeWindowClosed =>
                "DisputeWindowClosed".to_string(),
            ErrorCode::Unauthorized => "Unauthorized".to_string(),
        }
    }
}
impl From<ErrorCode> for u32 {
    fn from(e: ErrorCode) -> u32 {
        e as u32 + anchor_lang::error::ERROR_CODE_OFFSET
    }
}
impl From<ErrorCode> for anchor_lang::error::Error {
    fn from(error_code: ErrorCode) -> anchor_lang::error::Error {
        anchor_lang::error::Error::from(anchor_lang::error::AnchorError {
                error_name: error_code.name(),
                error_code_number: error_code.into(),
                error_msg: error_code.to_string(),
                error_origin: None,
                compared_values: None,
            })
    }
}
impl ::std::fmt::Display for ErrorCode {
    fn fmt(&self, fmt: &mut ::std::fmt::Formatter<'_>)
        -> ::std::result::Result<(), ::std::fmt::Error> {
        match self {
            ErrorCode::Paused =>
                fmt.write_fmt(format_args!("program paused")),
            ErrorCode::InvalidInput =>
                fmt.write_fmt(format_args!("invalid input")),
            ErrorCode::InvalidExpiry =>
                fmt.write_fmt(format_args!("invalid expiry")),
            ErrorCode::InvalidState =>
                fmt.write_fmt(format_args!("invalid state")),
            ErrorCode::TooEarly => fmt.write_fmt(format_args!("too early")),
            ErrorCode::Math => fmt.write_fmt(format_args!("math error")),
            ErrorCode::InvalidAddress =>
                fmt.write_fmt(format_args!("invalid address")),
            ErrorCode::SelfBooking =>
                fmt.write_fmt(format_args!("buyer and provider must differ")),
            ErrorCode::DisputeWindowClosed =>
                fmt.write_fmt(format_args!("dispute window is closed")),
            ErrorCode::Unauthorized =>
                fmt.write_fmt(format_args!("unauthorized")),
        }
    }
}
